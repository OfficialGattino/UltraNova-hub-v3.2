local UltraNovaGlobal = (getgenv and getgenv()) or _G
local U = assert(UltraNovaGlobal.UltraNovaV32, "UltraNova v3.2 core was not loaded")
local Players,UIS,RunService,TweenService,Lighting,SoundService,TeleportService,MarketplaceService,GuiService,VirtualUser,CoreGui,HttpService,Stats,ContentProvider,StarterGui = U.Players,U.UIS,U.RunService,U.TweenService,U.Lighting,U.SoundService,U.TeleportService,U.MarketplaceService,U.GuiService,U.VirtualUser,U.CoreGui,U.HttpService,U.Stats,U.ContentProvider,U.StarterGui
local LP,Camera,unpackArgs = U.LP,U.Camera,U.unpackArgs
local character,humanoid,root = U.character,U.humanoid,U.root
local GuiParent,C,ESP_PALETTE = U.GuiParent,U.C,U.ESP_PALETTE
local corner,stroke,gradient,padding = U.corner,U.stroke,U.gradient,U.padding
local S,original = U.S,U.original
local Gui,Main,Scale,refreshScale,Stars = U.Gui,U.Main,U.Scale,U.refreshScale,U.Stars
local MainLineFX,restartMainLineTweens = U.MainLineFX,U.restartMainLineTweens
local Header,NovaIcon,Title,SubTitle,Minimize,Mini,MiniLineFX,restartMiniLineTweens = U.Header,U.NovaIcon,U.Title,U.SubTitle,U.Minimize,U.Mini,U.MiniLineFX,U.restartMiniLineTweens
local toast = U.toast
local MenuAmbience,MenuWhoosh,syncMenuAudio = U.MenuAmbience,U.MenuWhoosh,U.syncMenuAudio
local Sidebar,SideList,Content,Pages,Navs = U.Sidebar,U.SideList,U.Content,U.Pages,U.Navs
local makePage,switchPage = U.makePage,U.switchPage
local Home,Cheats,PlayersPage,CameraPage,VisualsPage,Emotes,Shaders,ServerPage,PerformancePage,ToolsPage,SettingsPage = U.Home,U.Cheats,U.PlayersPage,U.CameraPage,U.VisualsPage,U.Emotes,U.Shaders,U.ServerPage,U.PerformancePage,U.ToolsPage,U.SettingsPage
local ControlRegistry,registerControl = U.ControlRegistry,U.registerControl
local heading,section,card,infoCard,button,toggle,slider = U.heading,U.section,U.card,U.infoCard,U.button,U.toggle,U.slider
local ModalDim,playerPicker = U.ModalDim,U.playerPicker

--========================================================
-- EMOTES
--========================================================
heading(Emotes,"EMOTES","10 dance mixes • Musica / Music")

local EmoteMusicEnabled = true
local EmoteVolume = .45
local CurrentDanceTrack = nil
local DanceToken = 0
local DanceSpeedMultiplier = 1
local DanceLoop = true
local DanceShuffle = false
local DancePlaylist = false
local DanceAutomationToken = 0
local NowPlayingDance = "None"

local DanceSound = Instance.new("Sound")
DanceSound.Name = "UltraNovaDanceMusic"
DanceSound.Volume = EmoteVolume
DanceSound.Looped = true
DanceSound.Parent = SoundService

-- Each preset mixes multiple clips instead of looping one move forever.
local DANCES = {
    {
        Name="Nova Groove", Music=1838673350, MusicSpeed=1,
        Clips={
            {R15=507771019,R6=182435998,Speed=1.02,Duration=4},
            {R15=507771955,R6=182491037,Speed=1.08,Duration=4}
        }
    },
    {
        Name="Cosmic Shuffle", Music=1837393392, MusicSpeed=1.03,
        Clips={
            {R15=507772104,R6=182491065,Speed=1.08,Duration=3.8},
            {R15=507776043,R6=182436842,Speed=1.16,Duration=3.8},
            {R15=507771955,R6=182491037,Speed=1.10,Duration=3.5}
        }
    },
    {
        Name="Zero-G Bounce", Music=1847000084, MusicSpeed=.96,
        Clips={
            {R15=507776720,R6=182491248,Speed=.96,Duration=4.2},
            {R15=507776879,R6=182491277,Speed=1.04,Duration=4.2}
        }
    },
    {
        Name="Purple Pulse", Music=1846869595, MusicSpeed=1.05,
        Clips={
            {R15=507777268,R6=182436935,Speed=1.14,Duration=3.6},
            {R15=507777451,R6=182491368,Speed=1.08,Duration=3.7}
        }
    },
    {
        Name="Orbit Funk", Music=1839256190, MusicSpeed=1,
        Clips={
            {R15=507777623,R6=182491423,Speed=1.08,Duration=3.8},
            {R15=507770677,R6=129423030,Speed=1.04,Duration=4}
        }
    },
    {
        Name="Nebula Mix", Music=1845554017, MusicSpeed=1.05,
        Clips={
            {R15=507771955,R6=182491037,Speed=1.08,Duration=3.3},
            {R15=507776720,R6=182491248,Speed=1.05,Duration=3.3},
            {R15=507777268,R6=182436935,Speed=1.15,Duration=3.3}
        }
    },
    {
        Name="Galaxy Rush", Music=1842976958, MusicSpeed=1.08,
        Clips={
            {R15=507776043,R6=182436842,Speed=1.20,Duration=3.2},
            {R15=507776879,R6=182491277,Speed=1.16,Duration=3.2},
            {R15=507777623,R6=182491423,Speed=1.22,Duration=3.2}
        }
    },
    {
        Name="Smooth Nova", Music=1838117725, MusicSpeed=.95,
        Clips={
            {R15=507771019,R6=182435998,Speed=.90,Duration=4.6},
            {R15=507777451,R6=182491368,Speed=.94,Duration=4.6}
        }
    },
    {
        Name="Glitch Step", Music=1840963785, MusicSpeed=1.10,
        Clips={
            {R15=507772104,R6=182491065,Speed=1.22,Duration=3},
            {R15=507777623,R6=182491423,Speed=1.28,Duration=3},
            {R15=507776720,R6=182491248,Speed=1.18,Duration=3}
        }
    },
    {
        Name="SUPERNOVA RAVE", Music=1846368080, MusicSpeed=1.10,
        Clips={
            {R15=507770677,R6=129423030,Speed=1.18,Duration=3.1},
            {R15=507777268,R6=182436935,Speed=1.24,Duration=3.1},
            {R15=507776879,R6=182491277,Speed=1.20,Duration=3.1},
            {R15=507777623,R6=182491423,Speed=1.25,Duration=3.1}
        }
    }
}

local function stopDance()
    DanceToken += 1
    if CurrentDanceTrack then
        pcall(function()
            CurrentDanceTrack:Stop(.18)
            CurrentDanceTrack:Destroy()
        end)
        CurrentDanceTrack = nil
    end
    pcall(function() DanceSound:Stop() end)
    NowPlayingDance = "None"
    S.activeDance = "None"
end

local function loadDanceClip(data)
    local h = humanoid()
    if not h then return nil end
    local animator = h:FindFirstChildOfClass("Animator")
    if not animator then
        animator = Instance.new("Animator")
        animator.Parent = h
    end
    local animation = Instance.new("Animation")
    local isR15 = h.RigType == Enum.HumanoidRigType.R15
    animation.AnimationId = "rbxassetid://"..tostring(isR15 and data.R15 or data.R6)
    local ok,track = pcall(function() return animator:LoadAnimation(animation) end)
    animation:Destroy()
    if not ok then return nil end
    return track
end

local function playDancePreset(preset)
    stopDance()
    if not humanoid() then
        toast("Personaggio non pronto / Character not ready",C.Red)
        return
    end

    DanceToken += 1
    local myToken = DanceToken

    if EmoteMusicEnabled then
        DanceSound.SoundId = "rbxassetid://"..tostring(preset.Music)
        DanceSound.Volume = EmoteVolume
        DanceSound.PlaybackSpeed = preset.MusicSpeed or 1
        pcall(function() DanceSound:Play() end)
    end

    task.spawn(function()
        while Gui.Parent and DanceToken == myToken do
            for _,clip in ipairs(preset.Clips) do
                if DanceToken ~= myToken then return end
                local track = loadDanceClip(clip)
                if track then
                    CurrentDanceTrack = track
                    track.Priority = Enum.AnimationPriority.Action
                    track.Looped = true
                    track:Play(.22,1,(clip.Speed or 1)*DanceSpeedMultiplier)
                    local started = os.clock()
                    local duration = clip.Duration or 4
                    while DanceToken == myToken and os.clock()-started < duration do
                        task.wait(.08)
                    end
                    pcall(function()
                        track:Stop(.22)
                        track:Destroy()
                    end)
                    if CurrentDanceTrack == track then CurrentDanceTrack = nil end
                end
            end
            if not DanceLoop then break end
        end
    end)

    NowPlayingDance = preset.Name
    S.activeDance = preset.Name
    toast(preset.Name.." ✦",C.Purple)
end

toggle(Emotes,"Musica / Music",true,function(on)
    EmoteMusicEnabled = on
    if not on then DanceSound:Stop() end
end)

slider(Emotes,"Volume musica / Music Volume",0,100,45,function(v)
    EmoteVolume = v/100
    DanceSound.Volume = EmoteVolume
end)

local SharedAudioToggle
SharedAudioToggle = toggle(Emotes,"Altri sentono musica / Others Hear Music",false,function(on)
    if on then
        task.defer(function()
            if SharedAudioToggle then SharedAudioToggle.Set(false) end
        end)
        toast("Serve il supporto audio del server / Game server support required",C.Orange)
    end
end)

button(Emotes,"■  Ferma ballo / Stop Dance",function() stopDance() end)
section(Emotes,"BALLI / DANCES")

for index,preset in ipairs(DANCES) do
    button(Emotes,string.format("%02d  ✦  %s",index,preset.Name),function()
        playDancePreset(preset)
    end)
end


section(Emotes,"EMOTES+ / DANCE CONTROL")

slider(Emotes,"Velocità ballo / Dance Speed",50,160,100,function(v)
    DanceSpeedMultiplier = v/100
    if CurrentDanceTrack then pcall(function() CurrentDanceTrack:AdjustSpeed(DanceSpeedMultiplier) end) end
end)

toggle(Emotes,"Loop ballo / Dance Loop",true,function(on)
    DanceLoop = on
end)

local NowPlayingCard,NowPlayingText = infoCard(Emotes,"♫ Now Playing","Dance: None")

task.spawn(function()
    while Gui.Parent do
        NowPlayingText.Text = "Dance: "..tostring(NowPlayingDance).."\nMusic: "..(EmoteMusicEnabled and "ON" or "OFF").." • Volume "..math.floor(EmoteVolume*100).."%"
        task.wait(.35)
    end
end)

button(Emotes,"⤨  Ballo casuale / Random Dance",function()
    local pick = DANCES[math.random(1,#DANCES)]
    playDancePreset(pick)
end)

toggle(Emotes,"Shuffle automatico / Auto Shuffle",false,function(on)
    DanceShuffle = on
    DanceAutomationToken += 1
    local token = DanceAutomationToken
    if on then
        DancePlaylist = false
        task.spawn(function()
            while Gui.Parent and DanceShuffle and token==DanceAutomationToken do
                playDancePreset(DANCES[math.random(1,#DANCES)])
                task.wait(12)
            end
        end)
    end
end)

toggle(Emotes,"Playlist 1→10 / Dance Playlist",false,function(on)
    DancePlaylist = on
    DanceAutomationToken += 1
    local token = DanceAutomationToken
    if on then
        DanceShuffle = false
        task.spawn(function()
            local i=1
            while Gui.Parent and DancePlaylist and token==DanceAutomationToken do
                playDancePreset(DANCES[i])
                i=i%#DANCES+1
                task.wait(12)
            end
        end)
    end
end)

infoCard(
    Emotes,
    "♫ UltraNova Dance Engine",
    "Ogni preset combina più movimenti con transizioni smooth. La musica può essere disattivata o regolata separatamente."
)



U.stopDance = stopDance
U.DanceSound = DanceSound
