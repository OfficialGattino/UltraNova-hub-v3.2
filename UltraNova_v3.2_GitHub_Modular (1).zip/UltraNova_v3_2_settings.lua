local UltraNovaGlobal = (getgenv and getgenv()) or _G
local U = assert(UltraNovaGlobal.UltraNovaV32, "UltraNova v3.2 core was not loaded")
local Players,UIS,RunService,TweenService,Lighting,SoundService,TeleportService,MarketplaceService,GuiService,VirtualUser,CoreGui,HttpService,Stats,ContentProvider,StarterGui = U.Players,U.UIS,U.RunService,U.TweenService,U.Lighting,U.SoundService,U.TeleportService,U.MarketplaceService,U.GuiService,U.VirtualUser,U.CoreGui,U.HttpService,U.Stats,U.ContentProvider,U.StarterGui
local LP,Camera,unpackArgs = U.LP,U.Camera,U.unpackArgs
local character,humanoid,root = U.character,U.humanoid,U.root
local GuiParent,C,ESP_PALETTE = U.GuiParent,U.C,U.ESP_PALETTE
local corner,stroke,gradient,padding = U.corner,U.stroke,U.gradient,U.padding
local S,original = U.S,U.original
local Gui,Main,Scale,refreshScale,Stars = U.Gui,U.Main,U.Scale,U.refreshScale,U.Stars
local MainLineFX,restartMainLineTweens = U.MainLineFX,U.restartMainLineTweens
local Header,NovaIcon,Title,SubTitle,Minimize,Mini,MiniLineFX,restartMiniLineTweens = U.Header,U.NovaIcon,U.Title,U.SubTitle,U.Minimize,U.Mini,U.MiniLineFX,U.restartMiniLineTweens
local toast = U.toast
local MenuAmbience,MenuWhoosh,syncMenuAudio = U.MenuAmbience,U.MenuWhoosh,U.syncMenuAudio
local Sidebar,SideList,Content,Pages,Navs = U.Sidebar,U.SideList,U.Content,U.Pages,U.Navs
local makePage,switchPage = U.makePage,U.switchPage
local Home,Cheats,PlayersPage,CameraPage,VisualsPage,Emotes,Shaders,ServerPage,PerformancePage,ToolsPage,SettingsPage = U.Home,U.Cheats,U.PlayersPage,U.CameraPage,U.VisualsPage,U.Emotes,U.Shaders,U.ServerPage,U.PerformancePage,U.ToolsPage,U.SettingsPage
local ControlRegistry,registerControl = U.ControlRegistry,U.registerControl
local heading,section,card,infoCard,button,toggle,slider = U.heading,U.section,U.card,U.infoCard,U.button,U.toggle,U.slider
local ModalDim,playerPicker = U.ModalDim,U.playerPicker

local ShaderPresets,applyShaderPreset = U.ShaderPresets,U.applyShaderPreset
local refreshEsp = U.refreshEsp
local FlyPad = U.FlyPad

--========================================================
-- SETTINGS PAGE
--========================================================
heading(SettingsPage,"SETTINGS","Themes • UI • Motion • Language • Profiles")

local ThemeOrder={"Purple","Blue","Cyan","Red","AMOLED"}; local ThemeIndex=1
local Themes={
    Purple={Space=Color3.fromRGB(7,5,17),Space2=Color3.fromRGB(13,8,30),Panel=Color3.fromRGB(20,14,43),Panel2=Color3.fromRGB(29,19,60),Purple=Color3.fromRGB(151,77,255),PurpleDark=Color3.fromRGB(97,46,191),Cyan=Color3.fromRGB(93,220,255),Blue=Color3.fromRGB(62,148,255)},
    Blue={Space=Color3.fromRGB(4,8,18),Space2=Color3.fromRGB(7,16,34),Panel=Color3.fromRGB(12,25,48),Panel2=Color3.fromRGB(18,36,67),Purple=Color3.fromRGB(69,130,255),PurpleDark=Color3.fromRGB(37,82,190),Cyan=Color3.fromRGB(92,226,255),Blue=Color3.fromRGB(55,145,255)},
    Cyan={Space=Color3.fromRGB(3,12,15),Space2=Color3.fromRGB(5,24,29),Panel=Color3.fromRGB(9,37,42),Panel2=Color3.fromRGB(12,51,58),Purple=Color3.fromRGB(45,230,236),PurpleDark=Color3.fromRGB(20,145,157),Cyan=Color3.fromRGB(155,255,255),Blue=Color3.fromRGB(45,175,225)},
    Red={Space=Color3.fromRGB(17,5,8),Space2=Color3.fromRGB(32,8,13),Panel=Color3.fromRGB(48,14,20),Panel2=Color3.fromRGB(66,20,29),Purple=Color3.fromRGB(255,72,92),PurpleDark=Color3.fromRGB(182,38,57),Cyan=Color3.fromRGB(255,173,184),Blue=Color3.fromRGB(226,71,115)},
    AMOLED={Space=Color3.fromRGB(0,0,0),Space2=Color3.fromRGB(2,2,4),Panel=Color3.fromRGB(8,8,12),Panel2=Color3.fromRGB(15,15,22),Purple=Color3.fromRGB(157,82,255),PurpleDark=Color3.fromRGB(90,42,170),Cyan=Color3.fromRGB(100,220,255),Blue=Color3.fromRGB(62,148,255)}
}

local function applyTheme(name)
    local t=Themes[name]; if not t then return end
    local old={Space=C.Space,Space2=C.Space2,Panel=C.Panel,Panel2=C.Panel2,Purple=C.Purple,PurpleDark=C.PurpleDark,Cyan=C.Cyan,Blue=C.Blue}
    for k,v in pairs(t) do C[k]=v end
    S.themeName=name
    for _,d in ipairs(Gui:GetDescendants()) do
        if d:IsA("GuiObject") then
            for k,ov in pairs(old) do if d.BackgroundColor3==ov and t[k] then d.BackgroundColor3=t[k] end end
            if d:IsA("TextLabel") or d:IsA("TextButton") or d:IsA("TextBox") then if d.TextColor3==old.Cyan then d.TextColor3=C.Cyan elseif d.TextColor3==old.Purple then d.TextColor3=C.Purple end end
        elseif d:IsA("UIStroke") then
            if d.Color==old.Purple then d.Color=C.Purple elseif d.Color==old.Cyan then d.Color=C.Cyan elseif d.Color==old.Blue then d.Color=C.Blue end
        end
    end
    toast("Theme: "..name,C.Cyan)
end

button(SettingsPage,"Theme: PURPLE",function(b)
    ThemeIndex=ThemeIndex%#ThemeOrder+1; local name=ThemeOrder[ThemeIndex]; b.Text="Theme: "..string.upper(name); applyTheme(name)
end)

slider(SettingsPage,"Velocità linee / Line Speed %",40,220,100,function(v)
    S.lineSpeed=v/100; restartMainLineTweens(); restartMiniLineTweens()
end)

toggle(SettingsPage,"Line FX",true,function(on)
    S.lineFx=on; restartMainLineTweens(); restartMiniLineTweens()
end)

toggle(SettingsPage,"Reduce Motion",false,function(on)
    S.reduceMotion=on; Stars.Visible=not on; restartMainLineTweens(); restartMiniLineTweens()
end)

slider(SettingsPage,"Dimensione GUI / GUI Size %",70,130,100,function(v)
    S.guiScale=v/100; refreshScale()
end)

slider(SettingsPage,"Trasparenza GUI / GUI Transparency",0,65,0,function(v)
    S.guiTransparency=v/100
    for _,d in ipairs(Gui:GetDescendants()) do
        if d:IsA("Frame") or d:IsA("TextButton") or d:IsA("ScrollingFrame") then
            if d:GetAttribute("UltraNovaBaseTransparency")==nil then d:SetAttribute("UltraNovaBaseTransparency",d.BackgroundTransparency) end
            local base=d:GetAttribute("UltraNovaBaseTransparency") or 0
            if d.BackgroundTransparency<1 then d.BackgroundTransparency=math.clamp(base+S.guiTransparency*.55,0,.9) end
        end
    end
end)

slider(SettingsPage,"Dimensione mini button / Mini Size %",75,140,100,function(v)
    local s=v/100; Mini.Size=UDim2.fromOffset(112*s,40*s)
end)

local function snapshotOriginalTexts()
    for _,d in ipairs(Gui:GetDescendants()) do
        if (d:IsA("TextLabel") or d:IsA("TextButton")) and d:GetAttribute("UltraNovaOriginalText")==nil then d:SetAttribute("UltraNovaOriginalText",d.Text) end
    end
end

local function applyLanguageMode(mode)
    snapshotOriginalTexts(); S.languageMode=mode
    for _,d in ipairs(Gui:GetDescendants()) do
        if d:IsA("TextLabel") or d:IsA("TextButton") then
            local originalText=d:GetAttribute("UltraNovaOriginalText")
            if originalText then
                if mode=="Bilingual" then d.Text=originalText
                else
                    local a,b=string.match(originalText,"^(.-)%s/%s(.-)$")
                    if a and b then d.Text=(mode=="IT") and a or b else d.Text=originalText end
                end
            end
        end
    end
end

local LanguageIndex=1; local Languages={"Bilingual","IT","EN"}
button(SettingsPage,"Lingua / Language: IT+EN",function(b)
    LanguageIndex=LanguageIndex%#Languages+1; local mode=Languages[LanguageIndex]; applyLanguageMode(mode); b.Text="Language: "..mode
end)

slider(SettingsPage,"Volume Menu Ambience",0,30,11,function(v) S.menuMusicVolume=v/100; syncMenuAudio() end)

section(SettingsPage,"PROFILES")
button(SettingsPage,"Profile: Default",function()
    S.speed=16; S.jump=50; S.gravity=196.2; S.flySpeed=55; workspace.Gravity=S.gravity; Camera.FieldOfView=70; applyTheme("Purple"); toast("Default profile",C.Cyan)
end)
button(SettingsPage,"Profile: Performance",function()
    S.speed=22; S.jump=55; Lighting.GlobalShadows=false; S.reduceMotion=true; Stars.Visible=false; restartMainLineTweens(); restartMiniLineTweens(); toast("Performance profile",C.Green)
end)
button(SettingsPage,"Profile: Visual",function()
    for _,p in ipairs(ShaderPresets) do if p.Name=="Deep Space" then applyShaderPreset(p) break end end; S.esp=true; refreshEsp(); toast("Visual profile",C.Purple)
end)
button(SettingsPage,"Profile: Movement",function()
    S.speed=32; S.jump=80; S.gravity=145; S.flySpeed=90; workspace.Gravity=S.gravity; toast("Movement profile",C.Cyan)
end)

local SETTINGS_FILE="UltraNova_v3_2_settings.json"
button(SettingsPage,"Save Custom Settings",function()
    if not writefile then toast("writefile unsupported",C.Orange) return end
    local data={speed=S.speed,jump=S.jump,gravity=S.gravity,flySpeed=S.flySpeed,fov=S.fov,guiScale=S.guiScale,lineSpeed=S.lineSpeed,theme=S.themeName,menuMusic=S.menuMusic,menuVolume=S.menuMusicVolume}
    local ok=pcall(function() writefile(SETTINGS_FILE,HttpService:JSONEncode(data)) end); toast(ok and "Settings saved" or "Save failed",ok and C.Green or C.Red)
end)
button(SettingsPage,"Load Custom Settings",function()
    if not readfile or (isfile and not isfile(SETTINGS_FILE)) then toast("No saved settings",C.Orange) return end
    local ok,data=pcall(function() return HttpService:JSONDecode(readfile(SETTINGS_FILE)) end)
    if ok and data then S.speed=data.speed or S.speed; S.jump=data.jump or S.jump; S.gravity=data.gravity or S.gravity; S.flySpeed=data.flySpeed or S.flySpeed; S.fov=data.fov or S.fov; S.guiScale=data.guiScale or S.guiScale; S.lineSpeed=data.lineSpeed or S.lineSpeed; S.menuMusic=(data.menuMusic~=false); S.menuMusicVolume=data.menuVolume or S.menuMusicVolume; workspace.Gravity=S.gravity; Camera.FieldOfView=S.fov; if data.theme then applyTheme(data.theme) end; refreshScale(); restartMainLineTweens(); restartMiniLineTweens(); syncMenuAudio(); toast("Settings loaded",C.Green) else toast("Load failed",C.Red) end
end)

--========================================================
-- COMMAND PALETTE / SEARCH
--========================================================
local SearchButton=Instance.new("TextButton")
SearchButton.Size=UDim2.fromOffset(40,34); SearchButton.Position=UDim2.new(1,-94,.5,-17); SearchButton.BackgroundColor3=C.Panel2; SearchButton.Text="⌕"; SearchButton.TextColor3=C.White; SearchButton.TextSize=18; SearchButton.Font=Enum.Font.GothamBold; SearchButton.ZIndex=11; SearchButton.Parent=Header; corner(SearchButton,10)

local SearchOverlay=Instance.new("Frame")
SearchOverlay.Size=UDim2.fromOffset(390,360); SearchOverlay.Position=UDim2.fromScale(.5,.5); SearchOverlay.AnchorPoint=Vector2.new(.5,.5); SearchOverlay.BackgroundColor3=C.Space2; SearchOverlay.Visible=false; SearchOverlay.ZIndex=160; SearchOverlay.Parent=Gui; corner(SearchOverlay,16); stroke(SearchOverlay,C.Purple,1.4,.08)
local SearchBox=Instance.new("TextBox"); SearchBox.Size=UDim2.new(1,-60,0,42); SearchBox.Position=UDim2.fromOffset(10,10); SearchBox.BackgroundColor3=C.Panel; SearchBox.PlaceholderText="Search UltraNova..."; SearchBox.Text=""; SearchBox.TextColor3=C.White; SearchBox.PlaceholderColor3=C.Soft; SearchBox.Font=Enum.Font.Gotham; SearchBox.TextSize=13; SearchBox.ClearTextOnFocus=false; SearchBox.ZIndex=161; SearchBox.Parent=SearchOverlay; corner(SearchBox,10)
local SearchClose=Instance.new("TextButton"); SearchClose.Size=UDim2.fromOffset(38,38); SearchClose.Position=UDim2.new(1,-48,0,12); SearchClose.BackgroundColor3=C.Panel2; SearchClose.Text="×"; SearchClose.TextColor3=C.White; SearchClose.ZIndex=161; SearchClose.Parent=SearchOverlay; corner(SearchClose,10)
local SearchResults=Instance.new("ScrollingFrame"); SearchResults.Size=UDim2.new(1,-20,1,-70); SearchResults.Position=UDim2.fromOffset(10,60); SearchResults.BackgroundTransparency=1; SearchResults.BorderSizePixel=0; SearchResults.AutomaticCanvasSize=Enum.AutomaticSize.Y; SearchResults.CanvasSize=UDim2.fromOffset(0,0); SearchResults.ScrollBarThickness=3; SearchResults.ZIndex=161; SearchResults.Parent=SearchOverlay; local SRList=Instance.new("UIListLayout"); SRList.Padding=UDim.new(0,6); SRList.Parent=SearchResults

local function refreshSearch()
    for _,d in ipairs(SearchResults:GetChildren()) do if d:IsA("TextButton") then d:Destroy() end end
    local q=string.lower(SearchBox.Text or ""); if #q<1 then return end
    local shown=0
    for _,entry in ipairs(ControlRegistry) do
        if string.find(string.lower(entry.Text),q,1,true) then
            shown+=1; if shown>25 then break end
            local b=Instance.new("TextButton"); b.Size=UDim2.new(1,-5,0,38); b.BackgroundColor3=C.Panel; b.Text=entry.Page.."  •  "..entry.Text; b.TextColor3=C.White; b.TextSize=11; b.TextXAlignment=Enum.TextXAlignment.Left; b.Font=Enum.Font.Gotham; b.ZIndex=162; b.Parent=SearchResults; corner(b,9)
            b.MouseButton1Click:Connect(function()
                SearchOverlay.Visible=false; Main.Visible=true; Mini.Visible=false; switchPage(entry.Page)
                local page=Pages[entry.Page]
                if page and entry.Frame and entry.Frame.Parent==page then page.CanvasPosition=Vector2.new(0,math.max(0,entry.Frame.AbsolutePosition.Y-page.AbsolutePosition.Y+page.CanvasPosition.Y-80)) end
            end)
        end
    end
end
SearchBox:GetPropertyChangedSignal("Text"):Connect(refreshSearch)
SearchButton.MouseButton1Click:Connect(function() SearchOverlay.Visible=true; SearchBox:CaptureFocus() end)
SearchClose.MouseButton1Click:Connect(function() SearchOverlay.Visible=false end)

--========================================================
-- QUICK MENU (long press UltraNova mini button)
--========================================================
local QuickMenu=Instance.new("Frame")
QuickMenu.Size=UDim2.fromOffset(190,255); QuickMenu.Position=UDim2.new(0,16,.52,26); QuickMenu.BackgroundColor3=C.Space2; QuickMenu.Visible=false; QuickMenu.ZIndex=145; QuickMenu.Parent=Gui; corner(QuickMenu,15); stroke(QuickMenu,C.Purple,1.3,.08)
local QL=Instance.new("UIListLayout"); QL.Padding=UDim.new(0,6); QL.Parent=QuickMenu; padding(QuickMenu,8,8,8,8)
local function qButton(text,fn) local b=Instance.new("TextButton"); b.Size=UDim2.new(1,0,0,40); b.BackgroundColor3=C.Panel; b.Text=text; b.TextColor3=C.White; b.TextSize=11; b.Font=Enum.Font.GothamSemibold; b.ZIndex=146; b.Parent=QuickMenu; corner(b,9); b.MouseButton1Click:Connect(fn); return b end
qButton("Fly ON/OFF",function() S.fly=not S.fly; FlyPad.Visible=S.fly; toast("Fly: "..(S.fly and "ON" or "OFF"),C.Purple) end)
qButton("Noclip ON/OFF",function() S.noclip=not S.noclip; toast("Noclip: "..(S.noclip and "ON" or "OFF"),C.Cyan) end)
qButton("ESP ON/OFF",function() S.esp=not S.esp; refreshEsp(); toast("ESP: "..(S.esp and "ON" or "OFF"),C.Cyan) end)
qButton("Fullbright",function() S.fullbright=not S.fullbright; if S.fullbright then Lighting.Brightness=3; Lighting.ClockTime=14; Lighting.GlobalShadows=false else Lighting.Brightness=original.Brightness; Lighting.ClockTime=original.ClockTime; Lighting.GlobalShadows=original.GlobalShadows end end)
qButton("Open UltraNova",function() QuickMenu.Visible=false; Mini.Visible=false; Main.Visible=true end)

local miniHoldStart=0
Mini.InputBegan:Connect(function(input)
    if input.UserInputType==Enum.UserInputType.Touch or input.UserInputType==Enum.UserInputType.MouseButton1 then
        miniHoldStart=os.clock()
        task.delay(.58,function()
            if U.isMiniDragging() and not U.isMiniMoved() and os.clock()-miniHoldStart>=.55 then
                QuickMenu.Position=UDim2.fromOffset(math.clamp(Mini.AbsolutePosition.X,4,Camera.ViewportSize.X-QuickMenu.AbsoluteSize.X-4),math.clamp(Mini.AbsolutePosition.Y+Mini.AbsoluteSize.Y+5,4,Camera.ViewportSize.Y-QuickMenu.AbsoluteSize.Y-4))
                QuickMenu.Visible=not QuickMenu.Visible
                U.setMiniMoved(true) -- prevents normal click opening the main window
            end
        end)
    end
end)

-- Language snapshot after all controls exist.
task.defer(snapshotOriginalTexts)

