local UltraNovaGlobal = (getgenv and getgenv()) or _G
local U = assert(UltraNovaGlobal.UltraNovaV32, "UltraNova v3.2 core was not loaded")
local Players,UIS,RunService,TweenService,Lighting,SoundService,TeleportService,MarketplaceService,GuiService,VirtualUser,CoreGui,HttpService,Stats,ContentProvider,StarterGui = U.Players,U.UIS,U.RunService,U.TweenService,U.Lighting,U.SoundService,U.TeleportService,U.MarketplaceService,U.GuiService,U.VirtualUser,U.CoreGui,U.HttpService,U.Stats,U.ContentProvider,U.StarterGui
local LP,Camera,unpackArgs = U.LP,U.Camera,U.unpackArgs
local character,humanoid,root = U.character,U.humanoid,U.root
local GuiParent,C,ESP_PALETTE = U.GuiParent,U.C,U.ESP_PALETTE
local corner,stroke,gradient,padding = U.corner,U.stroke,U.gradient,U.padding
local S,original = U.S,U.original
local Gui,Main,Scale,refreshScale,Stars = U.Gui,U.Main,U.Scale,U.refreshScale,U.Stars
local MainLineFX,restartMainLineTweens = U.MainLineFX,U.restartMainLineTweens
local Header,NovaIcon,Title,SubTitle,Minimize,Mini,MiniLineFX,restartMiniLineTweens = U.Header,U.NovaIcon,U.Title,U.SubTitle,U.Minimize,U.Mini,U.MiniLineFX,U.restartMiniLineTweens
local toast = U.toast
local MenuAmbience,MenuWhoosh,syncMenuAudio = U.MenuAmbience,U.MenuWhoosh,U.syncMenuAudio
local Sidebar,SideList,Content,Pages,Navs = U.Sidebar,U.SideList,U.Content,U.Pages,U.Navs
local makePage,switchPage = U.makePage,U.switchPage
local Home,Cheats,PlayersPage,CameraPage,VisualsPage,Emotes,Shaders,ServerPage,PerformancePage,ToolsPage,SettingsPage = U.Home,U.Cheats,U.PlayersPage,U.CameraPage,U.VisualsPage,U.Emotes,U.Shaders,U.ServerPage,U.PerformancePage,U.ToolsPage,U.SettingsPage
local ControlRegistry,registerControl = U.ControlRegistry,U.registerControl
local heading,section,card,infoCard,button,toggle,slider = U.heading,U.section,U.card,U.infoCard,U.button,U.toggle,U.slider
local ModalDim,playerPicker = U.ModalDim,U.playerPicker

--========================================================
-- SERVER PAGE
--========================================================
heading(ServerPage,"SERVER","Server tools • Hop • Small server • Live stats")
local ServerStatsCard,ServerStatsText=infoCard(ServerPage,"⌁ Server Status","")
task.spawn(function()
    while Gui.Parent do
        ServerStatsText.Text="Players: "..#Players:GetPlayers().." / "..Players.MaxPlayers.."\nPing: "..pingText().." • FPS: "..RuntimeFPS.."\nSession: "..uptimeText().."\nJobId: "..string.sub(game.JobId,1,18).."..."
        task.wait(.5)
    end
end)

local function fetchServers(sortOrder)
    local url="https://games.roblox.com/v1/games/"..game.PlaceId.."/servers/Public?sortOrder="..(sortOrder or "Asc").."&limit=100"
    local body=game:HttpGet(url)
    return HttpService:JSONDecode(body).data or {}
end

local function hopServer(mode)
    toast("Cerco server / Searching...",C.Cyan)
    task.spawn(function()
        local ok,servers=pcall(fetchServers,mode=="random" and "Desc" or "Asc")
        if not ok then toast("Server list unavailable",C.Red) return end
        local candidates={}
        for _,s in ipairs(servers) do if s.id~=game.JobId and s.playing<s.maxPlayers then table.insert(candidates,s) end end
        if #candidates==0 then toast("Nessun server trovato / No server found",C.Orange) return end
        local target
        if mode=="random" then target=candidates[math.random(1,#candidates)] else table.sort(candidates,function(a,b) return a.playing<b.playing end); target=candidates[1] end
        pcall(function() TeleportService:TeleportToPlaceInstance(game.PlaceId,target.id,LP) end)
    end)
end

button(ServerPage,"⟳ Rejoin",function() TeleportService:Teleport(game.PlaceId,LP) end)
button(ServerPage,"⇄ Server Hop",function() hopServer("random") end)
button(ServerPage,"⇣ Join Smallest Server",function() hopServer("small") end)
button(ServerPage,"Copia JobId / Copy JobId",function() if setclipboard then setclipboard(game.JobId) else toast(game.JobId,C.Cyan) end end)
button(ServerPage,"Copia PlaceId / Copy PlaceId",function() if setclipboard then setclipboard(tostring(game.PlaceId)) else toast(tostring(game.PlaceId),C.Cyan) end end)

--========================================================
-- PERFORMANCE PAGE
--========================================================
heading(PerformancePage,"PERFORMANCE","FPS • Ping • Low Graphics • Restore")
local PerfCard,PerfText=infoCard(PerformancePage,"⚡ Live Performance","")
task.spawn(function()
    while Gui.Parent do PerfText.Text="FPS: "..RuntimeFPS.."\nPing: "..pingText().."\nMemory: "..memoryText().."\nSession: "..uptimeText(); task.wait(.5) end
end)

local FpsCaps={30,45,60,90,120,144,240}; local FpsCapIndex=3
button(PerformancePage,"FPS Cap: 60",function(b)
    FpsCapIndex=FpsCapIndex%#FpsCaps+1; local cap=FpsCaps[FpsCapIndex]; b.Text="FPS Cap: "..cap
    if setfpscap then pcall(function() setfpscap(cap) end) else toast("setfpscap unsupported",C.Orange) end
end)

local PerfBackup={}
local ParticleBackup={}
local function backupPart(p) if not PerfBackup[p] then PerfBackup[p]={Material=p.Material,Reflectance=p.Reflectance,CastShadow=p.CastShadow} end end

button(PerformancePage,"Low Graphics",function()
    task.spawn(function()
        local n=0
        for _,d in ipairs(workspace:GetDescendants()) do
            if d:IsA("BasePart") and not d:IsDescendantOf(character()) then
                backupPart(d); d.Material=Enum.Material.SmoothPlastic; d.Reflectance=0; d.CastShadow=false; n+=1
                if n%350==0 then task.wait() end
            end
        end
        Lighting.GlobalShadows=false; toast("Low Graphics ON",C.Green)
    end)
end)

button(PerformancePage,"Disable Particles",function()
    for _,d in ipairs(workspace:GetDescendants()) do
        if d:IsA("ParticleEmitter") or d:IsA("Trail") or d:IsA("Smoke") or d:IsA("Fire") or d:IsA("Sparkles") then if ParticleBackup[d]==nil then ParticleBackup[d]=d.Enabled end; d.Enabled=false end
    end
    toast("Particles OFF",C.Green)
end)

button(PerformancePage,"Disable Shadows",function() Lighting.GlobalShadows=false; for _,d in ipairs(workspace:GetDescendants()) do if d:IsA("BasePart") then backupPart(d); d.CastShadow=false end end end)

button(PerformancePage,"POTATO MODE",function()
    Lighting.GlobalShadows=false
    task.spawn(function()
        local n=0
        for _,d in ipairs(workspace:GetDescendants()) do
            if d:IsA("BasePart") and not d:IsDescendantOf(character()) then
                backupPart(d); d.Material=Enum.Material.SmoothPlastic; d.Reflectance=0; d.CastShadow=false; n+=1
                if n%400==0 then task.wait() end
            end
            if d:IsA("ParticleEmitter") or d:IsA("Trail") or d:IsA("Smoke") or d:IsA("Fire") or d:IsA("Sparkles") then if ParticleBackup[d]==nil then ParticleBackup[d]=d.Enabled end; d.Enabled=false end
        end
        toast("POTATO MODE 🥔",C.Orange)
    end)
end)

button(PerformancePage,"Restore Graphics",function()
    for p,v in pairs(PerfBackup) do if p and p.Parent then p.Material=v.Material; p.Reflectance=v.Reflectance; p.CastShadow=v.CastShadow end end; PerfBackup={}
    for d,v in pairs(ParticleBackup) do if d and d.Parent then d.Enabled=v end end; ParticleBackup={}
    Lighting.GlobalShadows=original.GlobalShadows
    toast("Graphics restored",C.Cyan)
end)

--========================================================
-- TOOLS PAGE
--========================================================
heading(ToolsPage,"TOOLS","Coordinates • Waypoints • Clipboard • Session")
local CoordCard,CoordText=infoCard(ToolsPage,"＋ Coordinates","")
local CoordHudEnabled=false
local CoordHud=Instance.new("TextLabel"); CoordHud.Size=UDim2.fromOffset(250,30); CoordHud.Position=UDim2.new(.5,-125,0,10); CoordHud.BackgroundColor3=C.Space2; CoordHud.BackgroundTransparency=.25; CoordHud.TextColor3=C.Cyan; CoordHud.Font=Enum.Font.GothamBold; CoordHud.TextSize=11; CoordHud.Visible=false; CoordHud.ZIndex=75; CoordHud.Parent=Gui; corner(CoordHud,10)

task.spawn(function()
    while Gui.Parent do
        local r=root(); local txt="Position unavailable"
        if r then txt=string.format("X %.1f   Y %.1f   Z %.1f",r.Position.X,r.Position.Y,r.Position.Z) end
        CoordText.Text=txt.."\nSession: "..uptimeText(); CoordHud.Text=txt; CoordHud.Visible=CoordHudEnabled; task.wait(.15)
    end
end)

toggle(ToolsPage,"Coordinates HUD",false,function(on) CoordHudEnabled=on end)
button(ToolsPage,"Copia posizione / Copy Position",function()
    local r=root(); if not r then return end; local txt=string.format("%.3f, %.3f, %.3f",r.Position.X,r.Position.Y,r.Position.Z); if setclipboard then setclipboard(txt) else toast(txt,C.Cyan) end
end)
button(ToolsPage,"Copia CFrame / Copy CFrame",function()
    local r=root(); if not r then return end; local c={r.CFrame:GetComponents()}; local out="CFrame.new("..table.concat(c,", ")..")"; if setclipboard then setclipboard(out) else toast("CFrame ready",C.Cyan) end
end)
button(ToolsPage,"Copia timestamp / Copy Timestamp",function()
    local t=os.date("!%Y-%m-%dT%H:%M:%SZ"); if setclipboard then setclipboard(t) else toast(t,C.Cyan) end
end)

local Waypoints={}
for i=1,5 do
    button(ToolsPage,"Save Waypoint "..i,function()
        local r=root(); if r then Waypoints[i]=r.CFrame; toast("Waypoint "..i.." saved",C.Green) end
    end)
    button(ToolsPage,"Go Waypoint "..i,function()
        local r=root(); if r and Waypoints[i] then r.CFrame=Waypoints[i] else toast("Waypoint "..i.." empty",C.Orange) end
    end)
end



U.CoordHud = CoordHud
