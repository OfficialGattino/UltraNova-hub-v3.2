local UltraNovaGlobal = (getgenv and getgenv()) or _G
local U = assert(UltraNovaGlobal.UltraNovaV32, "UltraNova v3.2 core was not loaded")
local Players,UIS,RunService,TweenService,Lighting,SoundService,TeleportService,MarketplaceService,GuiService,VirtualUser,CoreGui,HttpService,Stats,ContentProvider,StarterGui = U.Players,U.UIS,U.RunService,U.TweenService,U.Lighting,U.SoundService,U.TeleportService,U.MarketplaceService,U.GuiService,U.VirtualUser,U.CoreGui,U.HttpService,U.Stats,U.ContentProvider,U.StarterGui
local LP,Camera,unpackArgs = U.LP,U.Camera,U.unpackArgs
local character,humanoid,root = U.character,U.humanoid,U.root
local GuiParent,C,ESP_PALETTE = U.GuiParent,U.C,U.ESP_PALETTE
local corner,stroke,gradient,padding = U.corner,U.stroke,U.gradient,U.padding
local S,original = U.S,U.original
local Gui,Main,Scale,refreshScale,Stars = U.Gui,U.Main,U.Scale,U.refreshScale,U.Stars
local MainLineFX,restartMainLineTweens = U.MainLineFX,U.restartMainLineTweens
local Header,NovaIcon,Title,SubTitle,Minimize,Mini,MiniLineFX,restartMiniLineTweens = U.Header,U.NovaIcon,U.Title,U.SubTitle,U.Minimize,U.Mini,U.MiniLineFX,U.restartMiniLineTweens
local toast = U.toast
local MenuAmbience,MenuWhoosh,syncMenuAudio = U.MenuAmbience,U.MenuWhoosh,U.syncMenuAudio
local Sidebar,SideList,Content,Pages,Navs = U.Sidebar,U.SideList,U.Content,U.Pages,U.Navs
local makePage,switchPage = U.makePage,U.switchPage
local Home,Cheats,PlayersPage,CameraPage,VisualsPage,Emotes,Shaders,ServerPage,PerformancePage,ToolsPage,SettingsPage = U.Home,U.Cheats,U.PlayersPage,U.CameraPage,U.VisualsPage,U.Emotes,U.Shaders,U.ServerPage,U.PerformancePage,U.ToolsPage,U.SettingsPage
local ControlRegistry,registerControl = U.ControlRegistry,U.registerControl
local heading,section,card,infoCard,button,toggle,slider = U.heading,U.section,U.card,U.infoCard,U.button,U.toggle,U.slider
local ModalDim,playerPicker = U.ModalDim,U.playerPicker

--========================================================
-- ESP
--========================================================
section(Cheats,"ESP / VISUAL PLAYERS")

local EspFolder = Instance.new("Folder")
EspFolder.Name = "UltraNovaESP"
EspFolder.Parent = Gui

local EspObjects = {}

local function removeEsp(p)
    local o = EspObjects[p]
    if not o then return end
    pcall(function() o.HL:Destroy() end)
    pcall(function() o.BB:Destroy() end)
    EspObjects[p] = nil
end

local function clearEsp()
    for p in pairs(EspObjects) do
        removeEsp(p)
    end
end

local function shouldEsp(p)
    if not S.esp or p == LP then return false end
    if S.espTarget and p ~= S.espTarget then return false end
    return true
end

local function makeEsp(p)
    if not shouldEsp(p) then return end
    local c = p.Character
    if not c then return end

    local existing = EspObjects[p]
    if existing and existing.Char == c then return existing end
    if existing then removeEsp(p) end

    local hl = Instance.new("Highlight")
    hl.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
    hl.FillTransparency = .84
    hl.OutlineTransparency = .06
    hl.FillColor = S.espColor
    hl.OutlineColor = S.espColor
    hl.Adornee = c
    hl.Parent = EspFolder

    local bb = Instance.new("BillboardGui")
    bb.Size = UDim2.fromOffset(220,50)
    bb.StudsOffset = Vector3.new(0,3.25,0)
    bb.AlwaysOnTop = true
    bb.Adornee = c:FindFirstChild("Head") or c:FindFirstChild("HumanoidRootPart")
    bb.Parent = EspFolder

    local tx = Instance.new("TextLabel")
    tx.Size = UDim2.fromScale(1,1)
    tx.BackgroundTransparency = 1
    tx.Text = ""
    tx.TextColor3 = S.espColor
    tx.TextStrokeTransparency = .42
    tx.TextSize = 12
    tx.Font = Enum.Font.GothamBold
    tx.Parent = bb

    local obj = {HL=hl,BB=bb,TX=tx,Char=c}
    EspObjects[p] = obj
    return obj
end

local function refreshEsp()
    if not S.esp then
        clearEsp()
        return
    end

    for _,p in ipairs(Players:GetPlayers()) do
        if shouldEsp(p) then
            makeEsp(p)
        else
            removeEsp(p)
        end
    end
end

toggle(Cheats,"ESP giocatori / Player ESP",false,function(on)
    S.esp = on
    refreshEsp()
end)

local EspTargetButton
EspTargetButton = select(1,button(Cheats,"Target ESP: Tutti / Everyone",function()
    playerPicker("ESP Target",true,function(p)
        S.espTarget = p
        EspTargetButton.Text = "Target ESP: "..(p and ("@"..p.Name) or "Tutti / Everyone")
        refreshEsp()
    end)
end))

button(Cheats,"Colore ESP / ESP Color",function(b)
    S.espColorIndex = (S.espColorIndex % #ESP_PALETTE) + 1
    S.espColor = ESP_PALETTE[S.espColorIndex]
    b.TextColor3 = S.espColor
    refreshEsp()
end)

toggle(Cheats,"Nome utente ESP / Show Username",true,function(on)
    S.espName = on
end)

toggle(Cheats,"Distanza ESP / Show Distance",true,function(on)
    S.espDistance = on
end)

task.spawn(function()
    while Gui.Parent do
        if S.esp then
            refreshEsp()
            local myRoot = root()

            for p,o in pairs(EspObjects) do
                if p.Parent and o and o.Char and o.Char.Parent then
                    o.HL.FillColor = S.espColor
                    o.HL.OutlineColor = S.espColor
                    o.TX.TextColor3 = S.espColor

                    local lines = {}
                    if S.espName then
                        table.insert(lines,p.DisplayName.."  @"..p.Name)
                    end

                    if S.espDistance then
                        local pr = p.Character and p.Character:FindFirstChild("HumanoidRootPart")
                        if myRoot and pr then
                            table.insert(lines,string.format("%.0f studs",(pr.Position-myRoot.Position).Magnitude))
                        end
                    end

                    o.TX.Text = table.concat(lines,"\n")
                end
            end
        end
        task.wait(.18)
    end
end)

Players.PlayerRemoving:Connect(function(p)
    removeEsp(p)
    if S.espTarget == p then S.espTarget = nil end
    if S.aimTarget == p then S.aimTarget = nil end
end)

--========================================================
-- AIM / CROSSHAIR
--========================================================
section(Cheats,"AIM / CROSSHAIR")

local AimOverlay = Instance.new("ScreenGui")
AimOverlay.Name = "UltraNovaAimOverlay"
AimOverlay.IgnoreGuiInset = true
AimOverlay.ResetOnSpawn = false
AimOverlay.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
AimOverlay.Parent = GuiParent

local Cross = Instance.new("Frame")
Cross.Size = UDim2.fromOffset(70,70)
Cross.Position = UDim2.fromScale(.5,.5)
Cross.AnchorPoint = Vector2.new(.5,.5)
Cross.BackgroundTransparency = 1
Cross.Visible = false
Cross.ZIndex = 50
Cross.Parent = AimOverlay

local CrossH = Instance.new("Frame")
CrossH.AnchorPoint = Vector2.new(.5,.5)
CrossH.Position = UDim2.fromScale(.5,.5)
CrossH.Size = UDim2.fromOffset(S.crosshairSize,2)
CrossH.BackgroundColor3 = C.White
CrossH.ZIndex = 51
CrossH.Parent = Cross
corner(CrossH,2)

local CrossV = Instance.new("Frame")
CrossV.AnchorPoint = Vector2.new(.5,.5)
CrossV.Position = UDim2.fromScale(.5,.5)
CrossV.Size = UDim2.fromOffset(2,S.crosshairSize)
CrossV.BackgroundColor3 = C.White
CrossV.ZIndex = 51
CrossV.Parent = Cross
corner(CrossV,2)

local CrossDot = Instance.new("Frame")
CrossDot.AnchorPoint = Vector2.new(.5,.5)
CrossDot.Position = UDim2.fromScale(.5,.5)
CrossDot.Size = UDim2.fromOffset(5,5)
CrossDot.BackgroundColor3 = C.Purple
CrossDot.ZIndex = 52
CrossDot.Parent = Cross
corner(CrossDot,5)

local FovCircle = Instance.new("Frame")
FovCircle.AnchorPoint = Vector2.new(.5,.5)
FovCircle.Position = UDim2.fromScale(.5,.5)
FovCircle.Size = UDim2.fromOffset(S.aimFov*2,S.aimFov*2)
FovCircle.BackgroundTransparency = 1
FovCircle.Visible = false
FovCircle.ZIndex = 45
FovCircle.Parent = AimOverlay
corner(FovCircle,999)
local FovStroke = stroke(FovCircle,C.Purple,1.2,.28)

toggle(Cheats,"Crosshair / Mirino",false,function(on)
    S.crosshair = on
    Cross.Visible = on
end)

toggle(Cheats,"Ruota crosshair / Spin Crosshair",false,function(on)
    S.crosshairSpin = on
end)

slider(Cheats,"Dimensione crosshair / Crosshair Size",10,90,30,function(v)
    S.crosshairSize = v
    CrossH.Size = UDim2.fromOffset(v,S.crosshairThickness or 2)
    CrossV.Size = UDim2.fromOffset(S.crosshairThickness or 2,v)
end)

local function isSameTeam(p)
    if not S.aimTeamCheck then return false end
    if LP.Team == nil or p.Team == nil then return false end
    return LP.Team == p.Team
end

local function visibleTarget(part, p)
    if not S.aimWallCheck then return true end
    local origin = Camera.CFrame.Position
    local direction = part.Position-origin

    local params = RaycastParams.new()
    params.FilterType = Enum.RaycastFilterType.Exclude
    params.FilterDescendantsInstances = {character()}

    local result = workspace:Raycast(origin,direction,params)
    if not result then return true end
    return result.Instance and result.Instance:IsDescendantOf(p.Character)
end

local function validAimPart(p)
    if not p or p == LP or not p.Character then return nil end
    local h = p.Character:FindFirstChildOfClass("Humanoid")
    if not h or h.Health <= 0 then return nil end
    if isSameTeam(p) then return nil end

    local part = p.Character:FindFirstChild(S.aimPart)
        or p.Character:FindFirstChild("Head")
        or p.Character:FindFirstChild("HumanoidRootPart")

    if not part then return nil end
    if not visibleTarget(part,p) then return nil end
    return part
end

local function getAimTarget()
    Camera = workspace.CurrentCamera or Camera
    local center = Camera.ViewportSize/2

    -- specific selected player
    if S.aimTarget then
        local part = validAimPart(S.aimTarget)
        if part then
            local pos,onScreen = Camera:WorldToViewportPoint(part.Position)
            if onScreen then
                local dist = (Vector2.new(pos.X,pos.Y)-center).Magnitude
                if dist <= S.aimFov then
                    return part,S.aimTarget
                end
            end
        end
        return nil,nil
    end

    -- automatic nearest on screen
    local bestPart,bestPlayer,bestDist = nil,nil,S.aimFov

    for _,p in ipairs(Players:GetPlayers()) do
        local part = validAimPart(p)
        if part then
            local pos,onScreen = Camera:WorldToViewportPoint(part.Position)
            if onScreen and pos.Z > 0 then
                local dist = (Vector2.new(pos.X,pos.Y)-center).Magnitude
                if dist < bestDist then
                    bestDist = dist
                    bestPart = part
                    bestPlayer = p
                end
            end
        end
    end

    return bestPart,bestPlayer
end

toggle(Cheats,"Aimbot morbido / Smooth Aim Assist",false,function(on)
    S.aimbot = on
    FovCircle.Visible = on or S.silentAim
end)

local AimTargetButton
AimTargetButton = select(1,button(Cheats,"Aim Target: Automatico / Auto",function()
    playerPicker("Aim Target",true,function(p)
        S.aimTarget = p
        AimTargetButton.Text = "Aim Target: "..(p and ("@"..p.Name) or "Automatico / Auto")
    end)
end))

slider(Cheats,"FOV Aimbot / Aim FOV",40,400,180,function(v)
    S.aimFov = v
    FovCircle.Size = UDim2.fromOffset(v*2,v*2)
end)

slider(Cheats,"Morbidezza mira / Aim Smoothness",1,25,8,function(v)
    S.aimSmooth = v
end)

toggle(Cheats,"Wall Check / Controllo muri",true,function(on)
    S.aimWallCheck = on
end)

toggle(Cheats,"Team Check / Ignora compagni",false,function(on)
    S.aimTeamCheck = on
end)

button(Cheats,"Target Part: Head / Testa",function(b)
    S.aimPart = (S.aimPart == "Head") and "HumanoidRootPart" or "Head"
    b.Text = "Target Part: "..((S.aimPart=="Head") and "Head / Testa" or "Body / Corpo")
end)

RunService.RenderStepped:Connect(function(dt)
    Camera = workspace.CurrentCamera or Camera

    if S.crosshairSpin then
        Cross.Rotation = (Cross.Rotation + dt*100) % 360
    else
        Cross.Rotation = 0
    end

    FovCircle.Position = UDim2.fromScale(.5,.5)
    FovCircle.Size = UDim2.fromOffset(S.aimFov*2,S.aimFov*2)
    FovCircle.Visible = S.aimbot or S.silentAim

    if S.aimbot then
        local target = getAimTarget()
        if target then
            local goal = CFrame.new(Camera.CFrame.Position,target.Position)
            local alpha = math.clamp(dt*(28/math.max(1,S.aimSmooth)),0,1)
            Camera.CFrame = Camera.CFrame:Lerp(goal,alpha)
        end
    end
end)

-- Generic Silent Aim: Workspace:Raycast only.
local SilentInstalled = false
local OldNamecall = nil

local function installSilentAim()
    if SilentInstalled then return true end
    if not hookmetamethod or not getnamecallmethod or not newcclosure then
        return false
    end

    local ok = pcall(function()
        OldNamecall = hookmetamethod(game,"__namecall",newcclosure(function(self,...)
            local args = {...}
            local method = getnamecallmethod()

            if S.silentAim
            and method == "Raycast"
            and self == workspace
            and typeof(args[1]) == "Vector3"
            and typeof(args[2]) == "Vector3"
            and (not checkcaller or not checkcaller()) then

                local target = getAimTarget()
                if target then
                    local origin = args[1]
                    local oldDirection = args[2]
                    local mag = oldDirection.Magnitude
                    if mag > 0 then
                        args[2] = (target.Position-origin).Unit * mag
                        return OldNamecall(self,unpackArgs(args))
                    end
                end
            end

            return OldNamecall(self,...)
        end))
    end)

    SilentInstalled = ok
    return ok
end

local SilentToggle
SilentToggle = toggle(Cheats,"Silent Aim generico / Generic Silent Aim",false,function(on)
    if on then
        if not installSilentAim() then
            S.silentAim = false
            task.defer(function()
                if SilentToggle then SilentToggle.Set(false) end
            end)
            toast("Silent Aim non supportato da questo executor / unsupported",C.Red)
            return
        end
        S.silentAim = true
        FovCircle.Visible = true
        toast("Silent Aim: Raycast mode",C.Purple)
    else
        S.silentAim = false
        FovCircle.Visible = S.aimbot
    end
end)

--========================================================
-- WORLD / VISUALS
--========================================================
section(Cheats,"MONDO / VISUALS")

toggle(Cheats,"Fullbright / Luce completa",false,function(on)
    S.fullbright = on
    if on then
        Lighting.Brightness = 3
        Lighting.ClockTime = 14
        Lighting.GlobalShadows = false
        Lighting.Ambient = Color3.fromRGB(178,178,178)
        Lighting.OutdoorAmbient = Color3.fromRGB(178,178,178)
    else
        Lighting.Brightness = original.Brightness
        Lighting.ClockTime = original.ClockTime
        Lighting.GlobalShadows = original.GlobalShadows
    end
end)

toggle(Cheats,"No Fog / Rimuovi nebbia",false,function(on)
    S.noFog = on
    Lighting.FogEnd = on and 1000000 or original.FogEnd
end)

slider(Cheats,"Camera FOV / Campo visivo",50,120,math.floor(Camera.FieldOfView+.5),function(v)
    S.fov = v
    Camera.FieldOfView = v
end)

local XrayBackup = {}
toggle(Cheats,"X-Ray mondo / World X-Ray",false,function(on)
    S.xray = on

    if on then
        for _,p in ipairs(workspace:GetDescendants()) do
            if p:IsA("BasePart")
            and not p:IsDescendantOf(character())
            and not Players:GetPlayerFromCharacter(p.Parent) then
                if XrayBackup[p] == nil then
                    XrayBackup[p] = p.LocalTransparencyModifier
                end
                p.LocalTransparencyModifier = math.max(p.LocalTransparencyModifier,.62)
            end
        end
    else
        for p,val in pairs(XrayBackup) do
            if p and p.Parent then
                pcall(function() p.LocalTransparencyModifier = val end)
            end
        end
        XrayBackup = {}
    end
end)

button(Cheats,"FPS Boost leggero / Light FPS Boost",function()
    pcall(function()
        Lighting.GlobalShadows = false
        for _,d in ipairs(workspace:GetDescendants()) do
            if d:IsA("ParticleEmitter")
            or d:IsA("Trail")
            or d:IsA("Smoke")
            or d:IsA("Fire")
            or d:IsA("Sparkles") then
                d.Enabled = false
            end
        end
    end)
    toast("FPS Boost applicato / applied",C.Green)
end)

--========================================================
-- UTILITY
--========================================================
section(Cheats,"UTILITY")

toggle(Cheats,"Anti AFK / Anti Idle",false,function(on)
    S.antiAfk = on
end)

LP.Idled:Connect(function()
    if S.antiAfk then
        pcall(function()
            VirtualUser:CaptureController()
            VirtualUser:ClickButton2(Vector2.new(0,0))
        end)
    end
end)

button(Cheats,"Reset personaggio / Reset Character",function()
    local h = humanoid()
    if h then h.Health = 0 end
end)

button(Cheats,"Rejoin / Rientra nel server",function()
    toast("Rejoining...",C.Blue)
    pcall(function()
        TeleportService:Teleport(game.PlaceId,LP)
    end)
end)

button(Cheats,"Copia JobId / Copy Server JobId",function()
    if setclipboard then
        pcall(function()
            setclipboard(game.JobId)
            toast("JobId copiato / copied",C.Cyan)
        end)
    else
        toast(game.JobId,C.Cyan)
    end
end)

infoCard(
    Cheats,
    "✦ UltraNova",
    "Nessuna key. La lista giocatori viene aggiornata dal server corrente. "..
    "UltraNova è ottimizzata per touch, telefono e tablet."
)




U.refreshEsp = refreshEsp
U.clearEsp = clearEsp
U.AimOverlay = AimOverlay
