local UltraNovaGlobal = (getgenv and getgenv()) or _G
local U = assert(UltraNovaGlobal.UltraNovaV32, "UltraNova v3.2 core was not loaded")
local Players,UIS,RunService,TweenService,Lighting,SoundService,TeleportService,MarketplaceService,GuiService,VirtualUser,CoreGui,HttpService,Stats,ContentProvider,StarterGui = U.Players,U.UIS,U.RunService,U.TweenService,U.Lighting,U.SoundService,U.TeleportService,U.MarketplaceService,U.GuiService,U.VirtualUser,U.CoreGui,U.HttpService,U.Stats,U.ContentProvider,U.StarterGui
local LP,Camera,unpackArgs = U.LP,U.Camera,U.unpackArgs
local character,humanoid,root = U.character,U.humanoid,U.root
local GuiParent,C,ESP_PALETTE = U.GuiParent,U.C,U.ESP_PALETTE
local corner,stroke,gradient,padding = U.corner,U.stroke,U.gradient,U.padding
local S,original = U.S,U.original
local Gui,Main,Scale,refreshScale,Stars = U.Gui,U.Main,U.Scale,U.refreshScale,U.Stars
local MainLineFX,restartMainLineTweens = U.MainLineFX,U.restartMainLineTweens
local Header,NovaIcon,Title,SubTitle,Minimize,Mini,MiniLineFX,restartMiniLineTweens = U.Header,U.NovaIcon,U.Title,U.SubTitle,U.Minimize,U.Mini,U.MiniLineFX,U.restartMiniLineTweens
local toast = U.toast
local MenuAmbience,MenuWhoosh,syncMenuAudio = U.MenuAmbience,U.MenuWhoosh,U.syncMenuAudio
local Sidebar,SideList,Content,Pages,Navs = U.Sidebar,U.SideList,U.Content,U.Pages,U.Navs
local makePage,switchPage = U.makePage,U.switchPage
local Home,Cheats,PlayersPage,CameraPage,VisualsPage,Emotes,Shaders,ServerPage,PerformancePage,ToolsPage,SettingsPage = U.Home,U.Cheats,U.PlayersPage,U.CameraPage,U.VisualsPage,U.Emotes,U.Shaders,U.ServerPage,U.PerformancePage,U.ToolsPage,U.SettingsPage
local ControlRegistry,registerControl = U.ControlRegistry,U.registerControl
local heading,section,card,infoCard,button,toggle,slider = U.heading,U.section,U.card,U.infoCard,U.button,U.toggle,U.slider
local ModalDim,playerPicker = U.ModalDim,U.playerPicker

--========================================================
-- HOME
--========================================================
local gameName = "Unknown"
pcall(function()
    gameName = MarketplaceService:GetProductInfo(game.PlaceId).Name
end)

heading(Home, "ULTRANOVA HUB", "Space UI • Mobile / Tablet • No Key System")

local Credits, CreditsText = infoCard(
    Home,
    "✦  Crediti / Credits",
    "Creato da / Created by: OfficialGattino\n"..
    "Concept, nome e design: OfficialGattino\n"..
    "UltraNova Hub • v3.2"
)

local Info, InfoText = infoCard(Home,"◈  Sessione / Session","")
local function updateSession()
    local executor = "Unknown"
    pcall(function()
        if identifyexecutor then
            executor = tostring(select(1,identifyexecutor()))
        end
    end)
    InfoText.Text =
        "Gioco / Game: "..gameName..
        "\nGiocatori / Players: "..tostring(#Players:GetPlayers())..
        "\nExecutor: "..executor..
        "\nPlaceId: "..tostring(game.PlaceId)
end
updateSession()

Players.PlayerAdded:Connect(updateSession)
Players.PlayerRemoving:Connect(function() task.delay(.1,updateSession) end)

local YOUTUBE_URL = "https://www.youtube.com/@OfficialGattino"

button(Home,"▶  OfficialGattino • YouTube",function()
    local opened = false

    pcall(function()
        GuiService:OpenBrowserWindow(YOUTUBE_URL)
        opened = true
    end)

    if not opened and setclipboard then
        pcall(function()
            setclipboard(YOUTUBE_URL)
            toast("Link YouTube copiato / YouTube link copied ✦",C.Red)
        end)
    elseif not opened then
        toast("YouTube: @OfficialGattino",C.Red)
    end
end)

button(Home,"⟳  Rejoin / Rientra nel server",function()
    toast("Rejoining...",C.Blue)
    pcall(function()
        TeleportService:Teleport(game.PlaceId,LP)
    end)
end)

button(Home,"⨯  Chiudi Hub / Unload Hub",function()
    Gui:Destroy()
end)

infoCard(
    Home,
    "⌁  Compatibilità / Compatibility",
    "Alcuni giochi possono ripristinare velocità, salto o teletrasporto. "..
    "Silent Aim dipende dal sistema di tiro usato dal gioco."
)

--========================================================
-- CHEATS PAGE
--========================================================
heading(Cheats,"CHEATS","Touch Friendly • Italiano / English")

--========================================================
-- PLAYER / MOVEMENT
--========================================================
section(Cheats,"MOVIMENTO / MOVEMENT")

slider(Cheats,"Velocità / WalkSpeed",8,120,16,function(v)
    S.speed = v
    local h = humanoid()
    if h then h.WalkSpeed = v end
end)

slider(Cheats,"Salto super / Jump Power",25,220,50,function(v)
    S.jump = v
    local h = humanoid()
    if h then
        pcall(function() h.UseJumpPower = true end)
        h.JumpPower = v
    end
end)

slider(Cheats,"Gravità / Gravity",20,300,math.floor(workspace.Gravity+.5),function(v)
    S.gravity = v
    workspace.Gravity = v
end)

toggle(Cheats,"Salto infinito / Infinite Jump",false,function(on)
    S.infiniteJump = on
end)

UIS.JumpRequest:Connect(function()
    if S.infiniteJump then
        local h = humanoid()
        if h then h:ChangeState(Enum.HumanoidStateType.Jumping) end
    end
end)

toggle(Cheats,"Auto salto / Auto Jump",false,function(on)
    S.autoJump = on
end)

toggle(Cheats,"Noclip / Attraversa muri",false,function(on)
    S.noclip = on
end)

local collisionBackup = {}
RunService.Stepped:Connect(function()
    if not S.noclip then return end
    local c = LP.Character
    if not c then return end
    for _,p in ipairs(c:GetDescendants()) do
        if p:IsA("BasePart") then
            if collisionBackup[p] == nil then collisionBackup[p] = p.CanCollide end
            p.CanCollide = false
        end
    end
end)

toggle(Cheats,"Invisibile locale / Local Invisible",false,function(on)
    S.localInvisible = on
    local c = LP.Character
    if not c then return end
    for _,d in ipairs(c:GetDescendants()) do
        if d:IsA("BasePart") then
            d.LocalTransparencyModifier = on and 1 or 0
        elseif d:IsA("Decal") then
            d.Transparency = on and 1 or 0
        end
    end
end)

-- Fly mobile buttons
local FlyPad = Instance.new("Frame")
FlyPad.Size = UDim2.fromOffset(60,130)
FlyPad.Position = UDim2.new(1,-78,.50,-65)
FlyPad.BackgroundTransparency = 1
FlyPad.Visible = false
FlyPad.ZIndex = 90
FlyPad.Parent = Gui

local function flyPadButton(text,y)
    local b = Instance.new("TextButton")
    b.Size = UDim2.fromOffset(58,58)
    b.Position = UDim2.fromOffset(0,y)
    b.BackgroundColor3 = C.Panel2
    b.Text = text
    b.TextColor3 = C.White
    b.TextSize = 22
    b.Font = Enum.Font.GothamBold
    b.AutoButtonColor = false
    b.ZIndex = 91
    b.Parent = FlyPad
    corner(b,15)
    stroke(b,C.Purple,1.2,.08)
    return b
end

local FlyUp = flyPadButton("▲",0)
local FlyDown = flyPadButton("▼",70)

local function verticalHold(btn, dir)
    btn.InputBegan:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.Touch
        or input.UserInputType == Enum.UserInputType.MouseButton1 then
            S.flyVertical = dir
        end
    end)
    btn.InputEnded:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.Touch
        or input.UserInputType == Enum.UserInputType.MouseButton1 then
            if S.flyVertical == dir then S.flyVertical = 0 end
        end
    end)
end
verticalHold(FlyUp,1)
verticalHold(FlyDown,-1)

toggle(Cheats,"Fly / Volo",false,function(on)
    S.fly = on
    FlyPad.Visible = on
    if on then
        toast("Fly: joystick + ▲ / ▼",C.Purple)
    else
        S.flyVertical = 0
    end
end)

slider(Cheats,"Velocità Fly / Fly Speed",10,150,55,function(v)
    S.flySpeed = v
end)

RunService.Heartbeat:Connect(function()
    local h = humanoid()
    local r = root()

    if h then
        if not S.fly then
            if math.abs(h.WalkSpeed - S.speed) > .1 then
                h.WalkSpeed = S.speed
            end
            pcall(function()
                h.UseJumpPower = true
                if math.abs(h.JumpPower - S.jump) > .1 then
                    h.JumpPower = S.jump
                end
            end)
        end

        if S.autoJump and h.MoveDirection.Magnitude > .08
        and h.FloorMaterial ~= Enum.Material.Air then
            h.Jump = true
        end
    end

    if S.fly and h and r then
        local vel = h.MoveDirection * S.flySpeed
        vel += Vector3.new(0,S.flyVertical*S.flySpeed,0)
        r.AssemblyLinearVelocity = vel
    end
end)

-- Air Walk
local AirPlatform = nil
toggle(Cheats,"Cammina nell'aria / Air Walk",false,function(on)
    S.airWalk = on
    if not on and AirPlatform then
        AirPlatform:Destroy()
        AirPlatform = nil
    end
end)

RunService.Heartbeat:Connect(function()
    if not S.airWalk then return end
    local r = root()
    if not r then return end

    if not AirPlatform or not AirPlatform.Parent then
        AirPlatform = Instance.new("Part")
        AirPlatform.Name = "UltraNovaAirWalk"
        AirPlatform.Size = Vector3.new(7,.5,7)
        AirPlatform.Anchored = true
        AirPlatform.CanCollide = true
        AirPlatform.Transparency = 1
        AirPlatform.Parent = workspace
    end

    AirPlatform.CFrame = CFrame.new(r.Position.X,r.Position.Y-3.15,r.Position.Z)
end)

toggle(Cheats,"Spin / Rotazione personaggio",false,function(on)
    S.spin = on
end)

slider(Cheats,"Velocità Spin / Spin Speed",1,30,8,function(v)
    S.spinSpeed = v
end)

RunService.Heartbeat:Connect(function(dt)
    if S.spin then
        local r = root()
        if r then
            r.CFrame = r.CFrame * CFrame.Angles(0,math.rad(S.spinSpeed*60*dt),0)
        end
    end
end)


--========================================================
-- MOVEMENT+ v3.2
--========================================================
section(Cheats,"MOVEMENT+ / EXTRA")

slider(Cheats,"Forza Dash / Dash Power",30,160,82,function(v)
    S.dashPower = v
end)

local dashReady = true
button(Cheats,"Dash / Scatto",function()
    if not dashReady then
        toast("Dash cooldown...",C.Orange)
        return
    end
    local r = root()
    local h = humanoid()
    if not r or not h then return end
    dashReady = false
    local dir = h.MoveDirection
    if dir.Magnitude < .05 then dir = Camera.CFrame.LookVector end
    local flat = Vector3.new(dir.X,0,dir.Z)
    if flat.Magnitude < .01 then flat = Vector3.new(0,0,-1) end
    r.AssemblyLinearVelocity = flat.Unit*S.dashPower + Vector3.new(0,r.AssemblyLinearVelocity.Y,0)
    task.delay(.65,function() dashReady=true end)
end)

button(Cheats,"Preset gravità bassa / Low Gravity",function()
    S.gravity = 82
    workspace.Gravity = S.gravity
    toast("Low Gravity: 82",C.Cyan)
end)

button(Cheats,"Preset salto alto / High Jump",function()
    S.jump = 105
    local h = humanoid()
    if h then pcall(function() h.UseJumpPower=true end) h.JumpPower=S.jump end
    toast("Jump Power: 105",C.Cyan)
end)

local LastSafeCFrame = nil
local SafeStableTime = 0

toggle(Cheats,"Anti-Void / Salvataggio caduta",false,function(on)
    S.antiVoid = on
    if on and root() then LastSafeCFrame = root().CFrame end
end)

slider(Cheats,"Profondità Anti-Void / Anti-Void Depth",25,120,48,function(v)
    S.antiVoidDepth = v
end)

toggle(Cheats,"Blocca posizione / Freeze Position",false,function(on)
    S.freezePosition = on
    local r = root()
    if r then r.Anchored = on end
end)

toggle(Cheats,"Float / Galleggia",false,function(on)
    S.float = on
end)

local WaterWalkPart = nil
toggle(Cheats,"Cammina sull'acqua / Water Walk",false,function(on)
    S.waterWalk = on
    if not on and WaterWalkPart then WaterWalkPart:Destroy() WaterWalkPart=nil end
end)

local FlyPresetIndex = 2
local FlyPresets = {
    {"Slow",28},{"Normal",55},{"Fast",90},{"Insane",140}
}
button(Cheats,"Fly Preset: NORMAL",function(b)
    FlyPresetIndex = FlyPresetIndex%#FlyPresets+1
    local preset = FlyPresets[FlyPresetIndex]
    S.flySpeed = preset[2]
    b.Text = "Fly Preset: "..string.upper(preset[1])
    toast("Fly Speed: "..tostring(preset[2]),C.Purple)
end)

RunService.Heartbeat:Connect(function(dt)
    local h,r = humanoid(),root()
    if not h or not r then return end

    if h.FloorMaterial ~= Enum.Material.Air and not S.fly and not S.airWalk then
        SafeStableTime += dt
        if SafeStableTime > .18 then LastSafeCFrame = r.CFrame end
    else
        SafeStableTime = 0
    end

    if S.antiVoid and LastSafeCFrame and r.Position.Y < LastSafeCFrame.Position.Y-S.antiVoidDepth then
        r.AssemblyLinearVelocity = Vector3.zero
        r.CFrame = LastSafeCFrame*CFrame.new(0,3,0)
        toast("Anti-Void ✦",C.Cyan)
    end

    if S.freezePosition and not r.Anchored then r.Anchored=true end
    if not S.freezePosition and r.Anchored then r.Anchored=false end

    if S.float and not S.fly then
        local v = r.AssemblyLinearVelocity
        r.AssemblyLinearVelocity = Vector3.new(v.X,0,v.Z)
    end

    if S.waterWalk then
        local params = RaycastParams.new()
        params.FilterType = Enum.RaycastFilterType.Exclude
        params.FilterDescendantsInstances = {character()}
        params.IgnoreWater = false
        local hit = workspace:Raycast(r.Position,Vector3.new(0,-7,0),params)
        if hit and hit.Material == Enum.Material.Water then
            if not WaterWalkPart or not WaterWalkPart.Parent then
                WaterWalkPart = Instance.new("Part")
                WaterWalkPart.Name="UltraNovaWaterWalk"
                WaterWalkPart.Size=Vector3.new(7,.35,7)
                WaterWalkPart.Anchored=true
                WaterWalkPart.CanCollide=true
                WaterWalkPart.Transparency=1
                WaterWalkPart.Parent=workspace
            end
            WaterWalkPart.CFrame=CFrame.new(hit.Position+Vector3.new(0,.1,0))
        elseif WaterWalkPart then
            WaterWalkPart.CFrame=CFrame.new(0,-10000,0)
        end
    end
end)

--========================================================
-- TELEPORT
--========================================================
section(Cheats,"TELEPORT")

button(Cheats,"TP a giocatore / Teleport to Player",function()
    playerPicker("TP • Lista giocatori / Player List",false,function(p)
        if not p then return end
        local r = root()
        local pr = p.Character and p.Character:FindFirstChild("HumanoidRootPart")
        if r and pr then
            r.CFrame = pr.CFrame * CFrame.new(0,0,3)
            toast("TP → @"..p.Name,C.Blue)
        end
    end)
end)

local SavedCF = nil
button(Cheats,"Salva posizione / Save Position",function()
    local r = root()
    if r then
        SavedCF = r.CFrame
        toast("Posizione salvata / Position saved",C.Green)
    end
end)

button(Cheats,"Torna alla posizione / Return to Saved",function()
    local r = root()
    if r and SavedCF then
        r.CFrame = SavedCF
    else
        toast("Nessuna posizione salvata / No saved position",C.Orange)
    end
end)

toggle(Cheats,"Tieni premuto per TP / Hold to Click TP",false,function(on)
    S.clickTP = on
    if on then
        toast("Tieni premuto ~0.45s nel mondo / Hold ~0.45s",C.Cyan)
    end
end)

do
    local activeInput = nil
    local started = nil
    local pos = nil

    UIS.InputBegan:Connect(function(input,gp)
        if gp or not S.clickTP then return end
        if input.UserInputType == Enum.UserInputType.Touch
        or input.UserInputType == Enum.UserInputType.MouseButton1 then
            activeInput = input
            started = os.clock()
            pos = input.Position
        end
    end)

    UIS.InputEnded:Connect(function(input,gp)
        if input ~= activeInput or not started or not S.clickTP then return end
        local held = os.clock() - started
        local endPos = input.Position
        activeInput = nil

        if held < .45 then return end
        if (Vector2.new(endPos.X,endPos.Y)-Vector2.new(pos.X,pos.Y)).Magnitude > 45 then return end

        if Main.Visible then
            local ap = Main.AbsolutePosition
            local as = Main.AbsoluteSize
            if endPos.X >= ap.X and endPos.X <= ap.X+as.X
            and endPos.Y >= ap.Y and endPos.Y <= ap.Y+as.Y then
                return
            end
        end

        local ray = Camera:ViewportPointToRay(endPos.X,endPos.Y)
        local params = RaycastParams.new()
        params.FilterType = Enum.RaycastFilterType.Exclude
        params.FilterDescendantsInstances = {character()}

        local hit = workspace:Raycast(ray.Origin,ray.Direction*1800,params)
        local r = root()
        if hit and r then
            r.CFrame = CFrame.new(hit.Position + Vector3.new(0,3,0))
        end
    end)
end



U.FlyPad = FlyPad
U.getAirPlatform = function() return AirPlatform end
U.getWaterWalkPart = function() return WaterWalkPart end
U.resetCollisionBackup = function() collisionBackup = {} end
