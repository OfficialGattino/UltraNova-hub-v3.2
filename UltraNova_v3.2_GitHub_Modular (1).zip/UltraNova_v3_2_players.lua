local UltraNovaGlobal = (getgenv and getgenv()) or _G
local U = assert(UltraNovaGlobal.UltraNovaV32, "UltraNova v3.2 core was not loaded")
local Players,UIS,RunService,TweenService,Lighting,SoundService,TeleportService,MarketplaceService,GuiService,VirtualUser,CoreGui,HttpService,Stats,ContentProvider,StarterGui = U.Players,U.UIS,U.RunService,U.TweenService,U.Lighting,U.SoundService,U.TeleportService,U.MarketplaceService,U.GuiService,U.VirtualUser,U.CoreGui,U.HttpService,U.Stats,U.ContentProvider,U.StarterGui
local LP,Camera,unpackArgs = U.LP,U.Camera,U.unpackArgs
local character,humanoid,root = U.character,U.humanoid,U.root
local GuiParent,C,ESP_PALETTE = U.GuiParent,U.C,U.ESP_PALETTE
local corner,stroke,gradient,padding = U.corner,U.stroke,U.gradient,U.padding
local S,original = U.S,U.original
local Gui,Main,Scale,refreshScale,Stars = U.Gui,U.Main,U.Scale,U.refreshScale,U.Stars
local MainLineFX,restartMainLineTweens = U.MainLineFX,U.restartMainLineTweens
local Header,NovaIcon,Title,SubTitle,Minimize,Mini,MiniLineFX,restartMiniLineTweens = U.Header,U.NovaIcon,U.Title,U.SubTitle,U.Minimize,U.Mini,U.MiniLineFX,U.restartMiniLineTweens
local toast = U.toast
local MenuAmbience,MenuWhoosh,syncMenuAudio = U.MenuAmbience,U.MenuWhoosh,U.syncMenuAudio
local Sidebar,SideList,Content,Pages,Navs = U.Sidebar,U.SideList,U.Content,U.Pages,U.Navs
local makePage,switchPage = U.makePage,U.switchPage
local Home,Cheats,PlayersPage,CameraPage,VisualsPage,Emotes,Shaders,ServerPage,PerformancePage,ToolsPage,SettingsPage = U.Home,U.Cheats,U.PlayersPage,U.CameraPage,U.VisualsPage,U.Emotes,U.Shaders,U.ServerPage,U.PerformancePage,U.ToolsPage,U.SettingsPage
local ControlRegistry,registerControl = U.ControlRegistry,U.registerControl
local heading,section,card,infoCard,button,toggle,slider = U.heading,U.section,U.card,U.infoCard,U.button,U.toggle,U.slider
local ModalDim,playerPicker = U.ModalDim,U.playerPicker

--========================================================
-- ULTRANOVA v3.2 EXPANSION
-- Players • Camera • Visuals • Server • Performance • Tools • Settings
--========================================================
local SessionStartedAt = os.clock()
local RuntimeFPS = 60
local frameCount = 0
local frameWindow = os.clock()

RunService.RenderStepped:Connect(function()
    frameCount += 1
    local now = os.clock()
    if now-frameWindow >= 1 then
        RuntimeFPS = math.floor(frameCount/(now-frameWindow)+.5)
        frameCount = 0
        frameWindow = now
    end
end)

local function pingText()
    local result = "?"
    pcall(function()
        result = Stats.Network.ServerStatsItem["Data Ping"]:GetValueString()
    end)
    return result
end

local function memoryText()
    local result = "?"
    pcall(function()
        result = string.format("%.0f MB",Stats:GetTotalMemoryUsageMb())
    end)
    return result
end

local function uptimeText()
    local s = math.floor(os.clock()-SessionStartedAt)
    return string.format("%02d:%02d:%02d",math.floor(s/3600),math.floor(s/60)%60,s%60)
end

--========================================================
-- HOME DASHBOARD + MENU MUSIC
--========================================================
section(Home,"DASHBOARD v3.2")
local DashboardCard,DashboardText = infoCard(Home,"✦ Live Dashboard","")

task.spawn(function()
    while Gui.Parent do
        DashboardText.Text =
            "FPS: "..tostring(RuntimeFPS).."  •  Ping: "..pingText().."\n"..
            "Players: "..tostring(#Players:GetPlayers()).."  •  Session: "..uptimeText().."\n"..
            "Shader: "..tostring(S.activeShader).."  •  Dance: "..tostring(S.activeDance)
        task.wait(.45)
    end
end)

local MenuMusicToggle
MenuMusicToggle = toggle(Home,"Musica del menù / Menu Music",true,function(on)
    S.menuMusic = on
    syncMenuAudio()
end)

slider(Home,"Volume menù / Menu Volume",0,30,11,function(v)
    S.menuMusicVolume = v/100
    syncMenuAudio()
end)

button(Home,"⚡  Quick Stats",function()
    toast("FPS "..RuntimeFPS.." • Ping "..pingText().." • "..#Players:GetPlayers().." players",C.Cyan)
end)

--========================================================
-- PLAYERS PAGE
--========================================================
heading(PlayersPage,"PLAYERS","Player tools • Spectate • Radar • Orbit")
local SelectedInfoCard,SelectedInfoText = infoCard(PlayersPage,"◎ Player selezionato / Selected Player","Nessuno / None")
local SelectedPlayerButton

local function selectedPlayerValid()
    return S.selectedPlayer and S.selectedPlayer.Parent==Players and S.selectedPlayer~=LP
end

local function selectedRoot()
    return selectedPlayerValid() and S.selectedPlayer.Character and S.selectedPlayer.Character:FindFirstChild("HumanoidRootPart")
end

local function selectedHumanoid()
    return selectedPlayerValid() and S.selectedPlayer.Character and S.selectedPlayer.Character:FindFirstChildOfClass("Humanoid")
end

SelectedPlayerButton = select(1,button(PlayersPage,"Scegli giocatore / Select Player",function(b)
    playerPicker("Players",false,function(p)
        S.selectedPlayer=p
        b.Text="Selected: @"..p.Name
    end)
end))

task.spawn(function()
    while Gui.Parent do
        if selectedPlayerValid() then
            local p=S.selectedPlayer
            local h=selectedHumanoid()
            local pr=selectedRoot()
            local mr=root()
            local dist=(pr and mr) and string.format("%.0f studs",(pr.Position-mr.Position).Magnitude) or "?"
            SelectedInfoText.Text = p.DisplayName.."  @"..p.Name.."\nUserId: "..p.UserId.." • Distance: "..dist.."\nHealth: "..(h and string.format("%.0f / %.0f",h.Health,h.MaxHealth) or "?")
        else
            SelectedInfoText.Text="Nessuno / None"
        end
        task.wait(.35)
    end
end)

button(PlayersPage,"👁  Spectate / Osserva",function()
    local h=selectedHumanoid()
    if h then Camera.CameraSubject=h else toast("Scegli un giocatore / Select a player",C.Orange) end
end)

button(PlayersPage,"↩  Stop Spectate",function()
    local h=humanoid()
    if h then Camera.CameraSubject=h end
end)

button(PlayersPage,"Avatar Card / Scheda Avatar",function()
    if not selectedPlayerValid() then toast("Scegli un giocatore / Select a player",C.Orange) return end
    local p=S.selectedPlayer
    local modal=Instance.new("Frame")
    modal.Size=UDim2.fromOffset(300,250)
    modal.Position=UDim2.fromScale(.5,.5)
    modal.AnchorPoint=Vector2.new(.5,.5)
    modal.BackgroundColor3=C.Space2
    modal.ZIndex=180
    modal.Parent=Gui
    corner(modal,16); stroke(modal,C.Purple,1.5,.08)
    local img=Instance.new("ImageLabel")
    img.Size=UDim2.fromOffset(120,120); img.Position=UDim2.new(.5,-60,0,18)
    img.BackgroundColor3=C.Panel; img.ZIndex=181; img.Parent=modal; corner(img,60)
    task.spawn(function()
        local ok,url=pcall(function() return Players:GetUserThumbnailAsync(p.UserId,Enum.ThumbnailType.AvatarBust,Enum.ThumbnailSize.Size420x420) end)
        if ok and img.Parent then img.Image=url end
    end)
    local tx=Instance.new("TextLabel")
    tx.Size=UDim2.new(1,-20,0,64); tx.Position=UDim2.fromOffset(10,142); tx.BackgroundTransparency=1
    tx.Text=p.DisplayName.."\n@"..p.Name.." • "..p.UserId; tx.TextColor3=C.White; tx.TextSize=13; tx.Font=Enum.Font.GothamBold; tx.ZIndex=181; tx.Parent=modal
    local close=Instance.new("TextButton")
    close.Size=UDim2.fromOffset(100,32); close.Position=UDim2.new(.5,-50,1,-42); close.BackgroundColor3=C.Panel2; close.Text="Close"; close.TextColor3=C.White; close.ZIndex=181; close.Parent=modal; corner(close,10)
    close.MouseButton1Click:Connect(function() modal:Destroy() end)
end)

button(PlayersPage,"Copia username / Copy Username",function()
    if not selectedPlayerValid() then return end
    if setclipboard then setclipboard(S.selectedPlayer.Name) else toast(S.selectedPlayer.Name,C.Cyan) end
end)

button(PlayersPage,"Copia UserId / Copy UserId",function()
    if not selectedPlayerValid() then return end
    if setclipboard then setclipboard(tostring(S.selectedPlayer.UserId)) else toast(tostring(S.selectedPlayer.UserId),C.Cyan) end
end)

button(PlayersPage,"TP dietro / TP Behind",function()
    local pr,r=selectedRoot(),root()
    if pr and r then r.CFrame=pr.CFrame*CFrame.new(0,0,4) end
end)

button(PlayersPage,"TP sopra / TP Above",function()
    local pr,r=selectedRoot(),root()
    if pr and r then r.CFrame=pr.CFrame*CFrame.new(0,7,0) end
end)

slider(PlayersPage,"Raggio Orbit / Orbit Radius",3,20,6,function(v) S.orbitRadius=v end)
slider(PlayersPage,"Velocità Orbit / Orbit Speed",1,10,2,function(v) S.orbitSpeed=v end)
toggle(PlayersPage,"Orbit Player",false,function(on) S.orbitPlayer=on end)
toggle(PlayersPage,"Health Monitor",false,function(on) S.healthMonitor=on end)
toggle(PlayersPage,"Radar 2D",false,function(on) S.playerRadar=on end)

local Radar = Instance.new("Frame")
Radar.Size=UDim2.fromOffset(150,150); Radar.Position=UDim2.new(1,-165,0,78); Radar.BackgroundColor3=C.Space2; Radar.BackgroundTransparency=.18; Radar.Visible=false; Radar.ZIndex=70; Radar.Parent=Gui
corner(Radar,75); stroke(Radar,C.Purple,1.2,.15)
local RadarDots={}

local HealthMonitorHud=Instance.new("TextLabel")
HealthMonitorHud.Size=UDim2.fromOffset(230,44)
HealthMonitorHud.Position=UDim2.new(0,14,0,78)
HealthMonitorHud.BackgroundColor3=C.Space2
HealthMonitorHud.BackgroundTransparency=.18
HealthMonitorHud.TextColor3=C.White
HealthMonitorHud.TextSize=11
HealthMonitorHud.Font=Enum.Font.GothamBold
HealthMonitorHud.Visible=false
HealthMonitorHud.ZIndex=73
HealthMonitorHud.Parent=Gui
corner(HealthMonitorHud,10)
stroke(HealthMonitorHud,C.Purple,1,.25)

RunService.RenderStepped:Connect(function()
    if S.orbitPlayer then
        local pr,r=selectedRoot(),root()
        if pr and r then
            local a=os.clock()*S.orbitSpeed
            local offset=Vector3.new(math.cos(a)*S.orbitRadius,1.5,math.sin(a)*S.orbitRadius)
            r.CFrame=CFrame.new(pr.Position+offset,pr.Position)
        end
    end

    HealthMonitorHud.Visible=S.healthMonitor and selectedPlayerValid()
    if HealthMonitorHud.Visible then
        local h=selectedHumanoid()
        HealthMonitorHud.Text="@"..S.selectedPlayer.Name.."  •  HP "..(h and string.format("%.0f / %.0f",h.Health,h.MaxHealth) or "?")
    end

    Radar.Visible=S.playerRadar
    if S.playerRadar then
        local mr=root()
        if mr then
            for _,p in ipairs(Players:GetPlayers()) do
                if p~=LP then
                    local dot=RadarDots[p]
                    if not dot then
                        dot=Instance.new("Frame"); dot.Size=UDim2.fromOffset(7,7); dot.AnchorPoint=Vector2.new(.5,.5); dot.BackgroundColor3=C.Cyan; dot.ZIndex=72; dot.Parent=Radar; corner(dot,5); RadarDots[p]=dot
                    end
                    local pr=p.Character and p.Character:FindFirstChild("HumanoidRootPart")
                    if pr then
                        local delta=pr.Position-mr.Position
                        local scale=math.min(1,Vector2.new(delta.X,delta.Z).Magnitude/150)
                        local dir=Vector2.new(delta.X,delta.Z)
                        if dir.Magnitude>0 then dir=dir.Unit end
                        dot.Position=UDim2.fromOffset(75+dir.X*scale*65,75+dir.Y*scale*65); dot.Visible=true
                    else dot.Visible=false end
                end
            end
        end
    end
end)

Players.PlayerRemoving:Connect(function(p)
    if RadarDots[p] then RadarDots[p]:Destroy(); RadarDots[p]=nil end
    if S.selectedPlayer==p then S.selectedPlayer=nil end
end)



U.Radar = Radar
U.HealthMonitorHud = HealthMonitorHud
