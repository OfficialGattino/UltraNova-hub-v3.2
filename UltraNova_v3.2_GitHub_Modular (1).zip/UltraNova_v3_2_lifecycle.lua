local UltraNovaGlobal = (getgenv and getgenv()) or _G
local U = assert(UltraNovaGlobal.UltraNovaV32, "UltraNova v3.2 core was not loaded")
local Players,UIS,RunService,TweenService,Lighting,SoundService,TeleportService,MarketplaceService,GuiService,VirtualUser,CoreGui,HttpService,Stats,ContentProvider,StarterGui = U.Players,U.UIS,U.RunService,U.TweenService,U.Lighting,U.SoundService,U.TeleportService,U.MarketplaceService,U.GuiService,U.VirtualUser,U.CoreGui,U.HttpService,U.Stats,U.ContentProvider,U.StarterGui
local LP,Camera,unpackArgs = U.LP,U.Camera,U.unpackArgs
local character,humanoid,root = U.character,U.humanoid,U.root
local GuiParent,C,ESP_PALETTE = U.GuiParent,U.C,U.ESP_PALETTE
local corner,stroke,gradient,padding = U.corner,U.stroke,U.gradient,U.padding
local S,original = U.S,U.original
local Gui,Main,Scale,refreshScale,Stars = U.Gui,U.Main,U.Scale,U.refreshScale,U.Stars
local MainLineFX,restartMainLineTweens = U.MainLineFX,U.restartMainLineTweens
local Header,NovaIcon,Title,SubTitle,Minimize,Mini,MiniLineFX,restartMiniLineTweens = U.Header,U.NovaIcon,U.Title,U.SubTitle,U.Minimize,U.Mini,U.MiniLineFX,U.restartMiniLineTweens
local toast = U.toast
local MenuAmbience,MenuWhoosh,syncMenuAudio = U.MenuAmbience,U.MenuWhoosh,U.syncMenuAudio
local Sidebar,SideList,Content,Pages,Navs = U.Sidebar,U.SideList,U.Content,U.Pages,U.Navs
local makePage,switchPage = U.makePage,U.switchPage
local Home,Cheats,PlayersPage,CameraPage,VisualsPage,Emotes,Shaders,ServerPage,PerformancePage,ToolsPage,SettingsPage = U.Home,U.Cheats,U.PlayersPage,U.CameraPage,U.VisualsPage,U.Emotes,U.Shaders,U.ServerPage,U.PerformancePage,U.ToolsPage,U.SettingsPage
local ControlRegistry,registerControl = U.ControlRegistry,U.registerControl
local heading,section,card,infoCard,button,toggle,slider = U.heading,U.section,U.card,U.infoCard,U.button,U.toggle,U.slider
local ModalDim,playerPicker = U.ModalDim,U.playerPicker

local refreshEsp,clearEsp = U.refreshEsp,U.clearEsp

--========================================================
-- RESPAWN REAPPLY
--========================================================
LP.CharacterAdded:Connect(function()
    task.wait(.8)

    local h = humanoid()
    if h then
        h.WalkSpeed = S.speed
        pcall(function()
            h.UseJumpPower = true
            h.JumpPower = S.jump
        end)
    end

    workspace.Gravity = S.gravity

    if S.localInvisible then
        local c = character()
        for _,d in ipairs(c:GetDescendants()) do
            if d:IsA("BasePart") then d.LocalTransparencyModifier = 1 end
        end
    end

    if U.resetCollisionBackup then U.resetCollisionBackup() end
    if refreshEsp then refreshEsp() end
end)

--========================================================
-- CLEANUP WHEN HUB REMOVED
--========================================================
Gui.AncestryChanged:Connect(function(_,parent)
    if parent ~= nil then return end

    S.fly = false
    S.noclip = false
    S.airWalk = false
    S.esp = false
    S.aimbot = false
    S.silentAim = false

    pcall(function()
        if U.setFreecam then U.setFreecam(false) end
    end)

    pcall(function()
        if U.AimOverlay then U.AimOverlay:Destroy() end
    end)

    pcall(function()
        if U.stopDance then U.stopDance() end
        if U.DanceSound then U.DanceSound:Destroy() end
    end)

    pcall(function()
        if U.resetShader then U.resetShader() end
    end)

    pcall(function()
        local folder=U.ShaderWorldFolder
        if folder and folder.Parent then folder:Destroy() end
    end)

    pcall(function()
        local air=U.getAirPlatform and U.getAirPlatform()
        if air then air:Destroy() end
    end)

    pcall(function()
        MenuAmbience:Destroy()
        MenuWhoosh:Destroy()
    end)

    pcall(function()
        if U.ExtraVisualGui then U.ExtraVisualGui:Destroy() end
        if U.VisualWorldFolder then U.VisualWorldFolder:Destroy() end
    end)

    pcall(function()
        if U.Radar then U.Radar:Destroy() end
        if U.HealthMonitorHud then U.HealthMonitorHud:Destroy() end
        if U.CoordHud then U.CoordHud:Destroy() end
        if U.FreeCamPad then U.FreeCamPad:Destroy() end
    end)

    pcall(function()
        local water=U.getWaterWalkPart and U.getWaterWalkPart()
        if water then water:Destroy() end
    end)

    pcall(function()
        if S.freezePosition and root() then root().Anchored=false end
    end)

    pcall(function()
        StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.All,true)
    end)

    if clearEsp then pcall(clearEsp) end
    UltraNovaGlobal.UltraNovaV32 = nil
end)

--========================================================
-- START
--========================================================
switchPage("Home")
toast("UltraNova Hub v3.2 ✦",C.Purple)
