--[[
    ╔══════════════════════════════════════════════════════╗
    ║                 UltraNova Hub v3.2                 ║
    ║            Created by OfficialGattino              ║
    ║   Single-file • No Key System • Mobile / Tablet    ║
    ╚══════════════════════════════════════════════════════╝

    UltraNova Hub
    Smooth mobile / tablet interface • No key system
]]

--========================================================
-- SERVICES
--========================================================
local Players = game:GetService("Players")
local UIS = game:GetService("UserInputService")
local RunService = game:GetService("RunService")
local TweenService = game:GetService("TweenService")
local Lighting = game:GetService("Lighting")
local SoundService = game:GetService("SoundService")
local TeleportService = game:GetService("TeleportService")
local MarketplaceService = game:GetService("MarketplaceService")
local GuiService = game:GetService("GuiService")
local VirtualUser = game:GetService("VirtualUser")
local CoreGui = game:GetService("CoreGui")
local HttpService = game:GetService("HttpService")
local Stats = game:GetService("Stats")
local ContentProvider = game:GetService("ContentProvider")
local StarterGui = game:GetService("StarterGui")

local LP = Players.LocalPlayer
local Camera = workspace.CurrentCamera
local unpackArgs = table.unpack or unpack

local function character()
    return LP.Character or LP.CharacterAdded:Wait()
end

local function humanoid()
    local c = LP.Character
    return c and c:FindFirstChildOfClass("Humanoid")
end

local function root()
    local c = LP.Character
    return c and c:FindFirstChild("HumanoidRootPart")
end

--========================================================
-- PARENT + CLEAN OLD UI
--========================================================
local GuiParent = LP:WaitForChild("PlayerGui")
pcall(function()
    if gethui then
        GuiParent = gethui()
    else
        GuiParent = CoreGui
    end
end)

pcall(function()
    local old = GuiParent:FindFirstChild("UltraNovaHub")
    if old then old:Destroy() end
    local oldAim = GuiParent:FindFirstChild("UltraNovaAimOverlay")
    if oldAim then oldAim:Destroy() end
end)

--========================================================
-- THEME
--========================================================
local C = {
    Space       = Color3.fromRGB(7, 5, 17),
    Space2      = Color3.fromRGB(13, 8, 30),
    Panel       = Color3.fromRGB(20, 14, 43),
    Panel2      = Color3.fromRGB(29, 19, 60),
    Panel3      = Color3.fromRGB(38, 24, 78),
    Purple      = Color3.fromRGB(151, 77, 255),
    PurpleDark  = Color3.fromRGB(97, 46, 191),
    Blue        = Color3.fromRGB(62, 148, 255),
    Cyan        = Color3.fromRGB(93, 220, 255),
    White       = Color3.fromRGB(246, 246, 255),
    Soft        = Color3.fromRGB(189, 184, 213),
    Green       = Color3.fromRGB(83, 255, 133),
    Red         = Color3.fromRGB(255, 72, 92),
    Orange      = Color3.fromRGB(255, 181, 76),
    Yellow      = Color3.fromRGB(255, 232, 91),
    Black       = Color3.fromRGB(4, 4, 10),
}

local ESP_PALETTE = {
    C.Purple, C.Blue, C.Cyan, C.Green, C.Red, C.Orange,
    C.Yellow, C.White, Color3.fromRGB(255, 90, 220)
}

local function corner(obj, radius)
    local x = Instance.new("UICorner")
    x.CornerRadius = UDim.new(0, radius or 10)
    x.Parent = obj
    return x
end

local function stroke(obj, color, thickness, transparency)
    local x = Instance.new("UIStroke")
    x.Color = color or C.Purple
    x.Thickness = thickness or 1
    x.Transparency = transparency or 0
    x.Parent = obj
    return x
end

local function gradient(obj, a, b, rot)
    local g = Instance.new("UIGradient")
    g.Color = ColorSequence.new(a, b)
    g.Rotation = rot or 0
    g.Parent = obj
    return g
end

local function padding(obj, l, r, t, b)
    local p = Instance.new("UIPadding")
    p.PaddingLeft = UDim.new(0, l or 0)
    p.PaddingRight = UDim.new(0, r or 0)
    p.PaddingTop = UDim.new(0, t or 0)
    p.PaddingBottom = UDim.new(0, b or 0)
    p.Parent = obj
end

--========================================================
-- STATE
--========================================================
local S = {
    speed = 16,
    jump = 50,
    gravity = workspace.Gravity,

    infiniteJump = false,
    autoJump = false,
    noclip = false,
    fly = false,
    flySpeed = 55,
    flyVertical = 0,
    clickTP = false,
    airWalk = false,
    spin = false,
    spinSpeed = 8,
    localInvisible = false,

    esp = false,
    espTarget = nil, -- nil = all
    espColor = C.Purple,
    espColorIndex = 1,
    espName = true,
    espDistance = true,

    fullbright = false,
    noFog = false,
    xray = false,
    fov = Camera.FieldOfView,

    crosshair = false,
    crosshairSpin = false,
    crosshairSize = 30,

    aimbot = false,
    aimTarget = nil, -- nil = auto nearest
    aimFov = 180,
    aimSmooth = 8,
    aimWallCheck = true,
    aimTeamCheck = false,
    aimPart = "Head",

    silentAim = false,

    antiAfk = false,

    -- v3.2 movement+
    dashPower = 82,
    antiVoid = false,
    antiVoidDepth = 48,
    freezePosition = false,
    float = false,
    waterWalk = false,

    -- v3.2 player tools
    selectedPlayer = nil,
    orbitPlayer = false,
    orbitRadius = 6,
    orbitSpeed = 2,
    playerRadar = false,
    healthMonitor = false,

    -- v3.2 visual extras
    tracers = false,
    boxEsp = false,
    healthBars = false,
    skeletonEsp = false,
    chams = false,
    playerGlow = false,
    rainbowEsp = false,
    espMaxDistance = 2500,
    nightVision = false,
    crosshairThickness = 2,
    crosshairOpacity = 0,
    crosshairColorIndex = 1,

    -- v3.2 camera
    freecam = false,
    freecamSpeed = 28,
    cameraRoll = 0,
    thirdPersonDistance = 12,

    -- v3.2 UI / settings
    menuMusic = true,
    menuMusicVolume = 0.11,
    lineSpeed = 1.0,
    lineFx = true,
    reduceMotion = false,
    guiScale = 1.0,
    guiTransparency = 0,
    languageMode = "Bilingual",
    themeName = "Purple",
    activeShader = "None",
    activeDance = "None",
}

local original = {
    Gravity = workspace.Gravity,
    Brightness = Lighting.Brightness,
    ClockTime = Lighting.ClockTime,
    FogEnd = Lighting.FogEnd,
    GlobalShadows = Lighting.GlobalShadows,
    Ambient = Lighting.Ambient,
    OutdoorAmbient = Lighting.OutdoorAmbient,
    ExposureCompensation = Lighting.ExposureCompensation,
    ColorShiftTop = Lighting.ColorShift_Top,
    ColorShiftBottom = Lighting.ColorShift_Bottom,
    EnvironmentDiffuseScale = Lighting.EnvironmentDiffuseScale,
    EnvironmentSpecularScale = Lighting.EnvironmentSpecularScale,
    FOV = Camera.FieldOfView,
}

--========================================================
-- ROOT GUI
--========================================================
local Gui = Instance.new("ScreenGui")
Gui.Name = "UltraNovaHub"
Gui.ResetOnSpawn = false
Gui.IgnoreGuiInset = false
Gui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
Gui.Parent = GuiParent

local Main = Instance.new("Frame")
Main.Name = "Main"
Main.Size = UDim2.fromOffset(670, 430)
Main.Position = UDim2.fromScale(.5, .5)
Main.AnchorPoint = Vector2.new(.5, .5)
Main.BackgroundColor3 = C.Space
Main.ClipsDescendants = true
Main.Parent = Gui
corner(Main, 18)
stroke(Main, C.Purple, 1.5, .10)
gradient(Main, C.Space, C.Space2, 35)

-- auto-scale for phone / tablet
local Scale = Instance.new("UIScale")
Scale.Parent = Main

local function refreshScale()
    Camera = workspace.CurrentCamera or Camera
    local v = Camera.ViewportSize
    local autoScale = math.clamp(math.min(v.X / 790, v.Y / 540), .62, 1)
    Scale.Scale = autoScale * (S.guiScale or 1)
end
refreshScale()
Camera:GetPropertyChangedSignal("ViewportSize"):Connect(refreshScale)

-- subtle moving stars
local Stars = Instance.new("Frame")
Stars.Size = UDim2.fromScale(1,1)
Stars.BackgroundTransparency = 1
Stars.ZIndex = 1
Stars.Parent = Main

for i = 1, 28 do
    local s = Instance.new("Frame")
    local sz = (i % 4 == 0) and 3 or 2
    s.Size = UDim2.fromOffset(sz, sz)
    s.Position = UDim2.new(((i * 37) % 100)/100, 0, ((i * 61) % 100)/100, 0)
    s.BackgroundColor3 = (i % 3 == 0) and C.Cyan or C.White
    s.BackgroundTransparency = .42 + ((i % 5) * .08)
    s.ZIndex = 1
    s.Parent = Stars
    corner(s, 8)

    TweenService:Create(
        s,
        TweenInfo.new(2.5 + (i % 5), Enum.EasingStyle.Sine, Enum.EasingDirection.InOut, -1, true),
        {BackgroundTransparency = .86}
    ):Play()
end

-- moving light streaks (v3.2: controllable speed / reduce motion)
local MainLineFX = {}

local function startMainLineTween(entry)
    if entry.Tween then pcall(function() entry.Tween:Cancel() end) end
    entry.Line.Position = entry.StartPos
    entry.Line.Visible = S.lineFx and not S.reduceMotion
    local duration = (5.4 + entry.Index * .52) / math.max(.25, S.lineSpeed or 1)
    entry.Tween = TweenService:Create(
        entry.Line,
        TweenInfo.new(duration, Enum.EasingStyle.Linear, Enum.EasingDirection.InOut, -1, true),
        {Position = entry.EndPos}
    )
    if entry.Line.Visible then entry.Tween:Play() end
end

local function restartMainLineTweens()
    for _,entry in ipairs(MainLineFX) do startMainLineTween(entry) end
end

for i = 1, 10 do
    local line = Instance.new("Frame")
    line.Size = UDim2.fromOffset(145 + i * 19, 1)
    line.BackgroundColor3 = (i % 3 == 0) and C.Cyan or C.White
    line.BackgroundTransparency = .80 + ((i % 3) * .035)
    line.Rotation = -12 + i * 2.4
    line.ZIndex = 1
    line.Parent = Main

    local entry = {
        Line = line,
        Index = i,
        StartPos = UDim2.new(-.58, 0, .035 + i * .087, 0),
        EndPos = UDim2.new(1.10, 0, .02 + i * .087, 0),
        Tween = nil
    }
    table.insert(MainLineFX, entry)
    startMainLineTween(entry)
end

--========================================================
-- HEADER
--========================================================
local Header = Instance.new("Frame")
Header.Size = UDim2.new(1, 0, 0, 58)
Header.BackgroundColor3 = C.Space2
Header.BackgroundTransparency = .05
Header.ZIndex = 10
Header.Parent = Main

local NovaIcon = Instance.new("TextLabel")
NovaIcon.Size = UDim2.fromOffset(42,42)
NovaIcon.Position = UDim2.fromOffset(10,8)
NovaIcon.BackgroundColor3 = C.PurpleDark
NovaIcon.Text = "✦"
NovaIcon.TextColor3 = C.White
NovaIcon.TextScaled = true
NovaIcon.Font = Enum.Font.GothamBold
NovaIcon.ZIndex = 11
NovaIcon.Parent = Header
corner(NovaIcon, 13)
stroke(NovaIcon, C.Cyan, 1.2, .15)
gradient(NovaIcon, C.PurpleDark, C.Blue, 45)

local Title = Instance.new("TextLabel")
Title.Size = UDim2.new(1,-185,1,0)
Title.Position = UDim2.fromOffset(62,0)
Title.BackgroundTransparency = 1
Title.Text = "UltraNova Hub"
Title.TextColor3 = C.White
Title.TextSize = 21
Title.TextXAlignment = Enum.TextXAlignment.Left
Title.Font = Enum.Font.GothamBold
Title.ZIndex = 11
Title.Parent = Header

local SubTitle = Instance.new("TextLabel")
SubTitle.Size = UDim2.new(1,-185,0,18)
SubTitle.Position = UDim2.fromOffset(64,34)
SubTitle.BackgroundTransparency = 1
SubTitle.Text = "OfficialGattino • UltraNova Hub"
SubTitle.TextColor3 = C.Soft
SubTitle.TextSize = 10
SubTitle.TextXAlignment = Enum.TextXAlignment.Left
SubTitle.Font = Enum.Font.Gotham
SubTitle.ZIndex = 11
SubTitle.Parent = Header

local Minimize = Instance.new("TextButton")
Minimize.Size = UDim2.fromOffset(40,34)
Minimize.Position = UDim2.new(1,-48,.5,-17)
Minimize.BackgroundColor3 = C.Panel2
Minimize.Text = "—"
Minimize.TextColor3 = C.White
Minimize.TextSize = 19
Minimize.Font = Enum.Font.GothamBold
Minimize.AutoButtonColor = false
Minimize.ZIndex = 11
Minimize.Parent = Header
corner(Minimize,10)

local Mini = Instance.new("TextButton")
Mini.Size = UDim2.fromOffset(112,40)
Mini.Position = UDim2.new(0,16,.52,-20)
Mini.BackgroundColor3 = C.Space2
Mini.Text = ""
Mini.AutoButtonColor = false
Mini.Visible = false
Mini.ZIndex = 80
Mini.ClipsDescendants = false
Mini.Parent = Gui
corner(Mini,13)

-- Animated purple/cyan/white border
local MiniStroke = stroke(Mini,C.Purple,1.6,.02)
local MiniStrokeGradient = Instance.new("UIGradient")
MiniStrokeGradient.Color = ColorSequence.new({
    ColorSequenceKeypoint.new(0,C.Purple),
    ColorSequenceKeypoint.new(.25,C.White),
    ColorSequenceKeypoint.new(.5,C.Cyan),
    ColorSequenceKeypoint.new(.75,C.Blue),
    ColorSequenceKeypoint.new(1,C.Purple)
})
MiniStrokeGradient.Parent = MiniStroke
TweenService:Create(
    MiniStrokeGradient,
    TweenInfo.new(2.8,Enum.EasingStyle.Linear,Enum.EasingDirection.InOut,-1,false),
    {Rotation=360}
):Play()

-- Inner clipping mask: moving lines stay inside the button
local MiniInner = Instance.new("Frame")
MiniInner.Size = UDim2.new(1,-8,1,-8)
MiniInner.Position = UDim2.fromOffset(4,4)
MiniInner.BackgroundColor3 = C.Space2
MiniInner.BackgroundTransparency = .08
MiniInner.ClipsDescendants = true
MiniInner.ZIndex = 81
MiniInner.Parent = Mini
corner(MiniInner,9)
gradient(MiniInner,C.Space2,C.Panel2,25)

local MiniLineFX = {}

local function startMiniLineTween(entry)
    if entry.Tween then pcall(function() entry.Tween:Cancel() end) end
    entry.Line.Position = entry.StartPos
    entry.Line.Visible = S.lineFx and not S.reduceMotion
    local duration = (1.55 + entry.Index * .16) / math.max(.25, S.lineSpeed or 1)
    entry.Tween = TweenService:Create(
        entry.Line,
        TweenInfo.new(duration,Enum.EasingStyle.Linear,Enum.EasingDirection.InOut,-1,false),
        {Position=entry.EndPos}
    )
    if entry.Line.Visible then entry.Tween:Play() end
end

local function restartMiniLineTweens()
    for _,entry in ipairs(MiniLineFX) do startMiniLineTween(entry) end
end

for i = 1,7 do
    local line = Instance.new("Frame")
    line.Size = UDim2.fromOffset(34+i*7,1)
    line.BackgroundColor3 = (i%3==0) and C.Cyan or C.White
    line.BackgroundTransparency = .68+(i%3)*.06
    line.ZIndex = 82
    line.Parent = MiniInner
    local entry = {
        Line=line, Index=i,
        StartPos=UDim2.new(-.7,0,.06+i*.115,0),
        EndPos=UDim2.new(1.12,0,.06+i*.115,0),
        Tween=nil
    }
    table.insert(MiniLineFX,entry)
    startMiniLineTween(entry)
end

local MiniLabel = Instance.new("TextLabel")
MiniLabel.Size = UDim2.fromScale(1,1)
MiniLabel.BackgroundTransparency = 1
MiniLabel.Text = "UltraNova"
MiniLabel.TextColor3 = C.White
MiniLabel.TextSize = 11
MiniLabel.TextStrokeTransparency = .65
MiniLabel.Font = Enum.Font.GothamBold
MiniLabel.ZIndex = 85
MiniLabel.Parent = Mini

local MiniStar = Instance.new("TextLabel")
MiniStar.Size = UDim2.fromOffset(20,20)
MiniStar.Position = UDim2.fromOffset(5,10)
MiniStar.BackgroundTransparency = 1
MiniStar.Text = "✦"
MiniStar.TextColor3 = C.Cyan
MiniStar.TextSize = 11
MiniStar.Font = Enum.Font.GothamBold
MiniStar.ZIndex = 86
MiniStar.Parent = Mini

local miniDragging = false
local miniDragStart
local miniStartAbsolute
local miniDragInput
local miniMoved = false

Mini.InputBegan:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.Touch
    or input.UserInputType == Enum.UserInputType.MouseButton1 then
        miniDragging = true
        miniMoved = false
        miniDragStart = input.Position
        miniStartAbsolute = Mini.AbsolutePosition
        input.Changed:Connect(function()
            if input.UserInputState == Enum.UserInputState.End then
                miniDragging = false
            end
        end)
    end
end)

Mini.InputChanged:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.Touch
    or input.UserInputType == Enum.UserInputType.MouseMovement then
        miniDragInput = input
    end
end)

UIS.InputChanged:Connect(function(input)
    if miniDragging and input == miniDragInput then
        local delta = input.Position-miniDragStart
        if delta.Magnitude > 5 then miniMoved = true end
        local viewport = Camera.ViewportSize
        local newX = math.clamp(miniStartAbsolute.X+delta.X,4,viewport.X-Mini.AbsoluteSize.X-4)
        local newY = math.clamp(miniStartAbsolute.Y+delta.Y,4,viewport.Y-Mini.AbsoluteSize.Y-4)
        Mini.Position = UDim2.fromOffset(newX,newY)
    end
end)

Minimize.MouseButton1Click:Connect(function()
    Main.Visible = false
    Mini.Visible = true
end)

Mini.MouseButton1Click:Connect(function()
    if miniMoved then
        miniMoved = false
        return
    end
    Mini.Visible = false
    Main.Visible = true
end)

-- drag Header: touch + mouse
do
    local dragging = false
    local dragStart
    local startPos
    local dragInput

    Header.InputBegan:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.Touch
        or input.UserInputType == Enum.UserInputType.MouseButton1 then
            dragging = true
            dragStart = input.Position
            startPos = Main.Position
            input.Changed:Connect(function()
                if input.UserInputState == Enum.UserInputState.End then
                    dragging = false
                end
            end)
        end
    end)

    Header.InputChanged:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.Touch
        or input.UserInputType == Enum.UserInputType.MouseMovement then
            dragInput = input
        end
    end)

    UIS.InputChanged:Connect(function(input)
        if dragging and input == dragInput then
            local d = input.Position - dragStart
            Main.Position = UDim2.new(
                startPos.X.Scale, startPos.X.Offset + d.X,
                startPos.Y.Scale, startPos.Y.Offset + d.Y
            )
        end
    end)
end

--========================================================
-- TOAST
--========================================================
local function toast(text, col)
    local f = Instance.new("Frame")
    f.Size = UDim2.fromOffset(350,54)
    f.Position = UDim2.new(.5,-175,1,18)
    f.BackgroundColor3 = C.Panel2
    f.ZIndex = 200
    f.Parent = Gui
    corner(f,13)
    stroke(f,col or C.Purple,1.3,.08)

    local l = Instance.new("TextLabel")
    l.Size = UDim2.new(1,-22,1,0)
    l.Position = UDim2.fromOffset(11,0)
    l.BackgroundTransparency = 1
    l.Text = tostring(text)
    l.TextColor3 = C.White
    l.TextSize = 13
    l.TextWrapped = true
    l.Font = Enum.Font.GothamMedium
    l.ZIndex = 201
    l.Parent = f

    TweenService:Create(f,TweenInfo.new(.24,Enum.EasingStyle.Quint),{
        Position = UDim2.new(.5,-175,1,-76)
    }):Play()

    task.delay(2.6,function()
        if not f.Parent then return end
        TweenService:Create(f,TweenInfo.new(.22),{
            Position = UDim2.new(.5,-175,1,18),
            BackgroundTransparency = 1
        }):Play()
        task.wait(.25)
        if f then f:Destroy() end
    end)
end


--========================================================
-- MENU MUSIC / SPACE AMBIENCE (v3.2)
--========================================================
local MenuAmbience = Instance.new("Sound")
MenuAmbience.Name = "UltraNovaMenuAmbience"
MenuAmbience.SoundId = "rbxassetid://1845421369" -- Space Atmosphere
MenuAmbience.Volume = S.menuMusicVolume
MenuAmbience.Looped = true
MenuAmbience.Parent = SoundService

local MenuWhoosh = Instance.new("Sound")
MenuWhoosh.Name = "UltraNovaMenuWhoosh"
MenuWhoosh.SoundId = "rbxassetid://9114340342" -- gentle sci-fi pass-by
MenuWhoosh.Volume = math.max(.035,S.menuMusicVolume*.65)
MenuWhoosh.Looped = false
MenuWhoosh.Parent = SoundService

pcall(function()
    task.spawn(function()
        ContentProvider:PreloadAsync({MenuAmbience,MenuWhoosh})
    end)
end)

local function syncMenuAudio()
    local shouldPlay = S.menuMusic and Main.Visible
    MenuAmbience.Volume = S.menuMusicVolume
    MenuWhoosh.Volume = math.max(.025,S.menuMusicVolume*.62)
    if shouldPlay then
        if not MenuAmbience.IsPlaying then pcall(function() MenuAmbience:Play() end) end
    else
        pcall(function() MenuAmbience:Pause() end)
        pcall(function() MenuWhoosh:Stop() end)
    end
end

Main:GetPropertyChangedSignal("Visible"):Connect(syncMenuAudio)

task.spawn(function()
    while Gui.Parent do
        task.wait(math.random(8,15))
        if S.menuMusic and Main.Visible and not S.reduceMotion then
            pcall(function()
                MenuWhoosh.PlaybackSpeed = math.random(92,108)/100
                MenuWhoosh:Play()
            end)
        end
    end
end)

task.defer(syncMenuAudio)

--========================================================
-- SIDEBAR / PAGES
--========================================================
local Sidebar = Instance.new("ScrollingFrame")
Sidebar.Size = UDim2.new(0,158,1,-58)
Sidebar.Position = UDim2.fromOffset(0,58)
Sidebar.BackgroundColor3 = C.Space2
Sidebar.BackgroundTransparency = .11
Sidebar.ZIndex = 8
Sidebar.Parent = Main
Sidebar.BorderSizePixel = 0
Sidebar.CanvasSize = UDim2.fromOffset(0,0)
Sidebar.AutomaticCanvasSize = Enum.AutomaticSize.Y
Sidebar.ScrollBarThickness = 2
Sidebar.ScrollBarImageColor3 = C.Purple
padding(Sidebar,8,8,12,8)

local SideList = Instance.new("UIListLayout")
SideList.Padding = UDim.new(0,8)
SideList.Parent = Sidebar

local Content = Instance.new("Frame")
Content.Size = UDim2.new(1,-158,1,-58)
Content.Position = UDim2.fromOffset(158,58)
Content.BackgroundTransparency = 1
Content.ZIndex = 8
Content.Parent = Main

local Pages = {}
local Navs = {}

local function makePage(name)
    local p = Instance.new("ScrollingFrame")
    p.Name = name
    p.Size = UDim2.fromScale(1,1)
    p.BackgroundTransparency = 1
    p.BorderSizePixel = 0
    p.ScrollBarThickness = 3
    p.ScrollBarImageColor3 = C.Purple
    p.AutomaticCanvasSize = Enum.AutomaticSize.Y
    p.CanvasSize = UDim2.fromOffset(0,0)
    p.Visible = false
    p.ZIndex = 9
    p.Parent = Content
    padding(p,14,14,14,20)

    local list = Instance.new("UIListLayout")
    list.Padding = UDim.new(0,9)
    list.Parent = p

    Pages[name] = p
    return p
end

local function switchPage(name)
    for n,p in pairs(Pages) do
        p.Visible = n == name
    end
    for n,b in pairs(Navs) do
        TweenService:Create(b,TweenInfo.new(.14),{
            BackgroundColor3 = (n == name) and C.PurpleDark or C.Panel
        }):Play()
    end
end

local function makeNav(name, text)
    local b = Instance.new("TextButton")
    b.Size = UDim2.new(1,0,0,42)
    b.BackgroundColor3 = C.Panel
    b.Text = text
    b.TextColor3 = C.White
    b.TextSize = 13
    b.Font = Enum.Font.GothamSemibold
    b.AutoButtonColor = false
    b.ZIndex = 10
    b.Parent = Sidebar
    corner(b,11)
    stroke(b,C.Purple,1,.68)

    b.MouseButton1Click:Connect(function()
        switchPage(name)
    end)

    Navs[name] = b
end

local Home = makePage("Home")
local Cheats = makePage("Cheats")
local PlayersPage = makePage("Players")
local CameraPage = makePage("Camera")
local VisualsPage = makePage("Visuals")
local Emotes = makePage("Emotes")
local Shaders = makePage("Shaders")
local ServerPage = makePage("Server")
local PerformancePage = makePage("Performance")
local ToolsPage = makePage("Tools")
local SettingsPage = makePage("Settings")

makeNav("Home","⌂   HOME")
makeNav("Cheats","✦   CHEATS")
makeNav("Players","◎   PLAYERS")
makeNav("Camera","◉   CAMERA")
makeNav("Visuals","◇   VISUALS")
makeNav("Emotes","♫   EMOTES")
makeNav("Shaders","◈   SHADERS")
makeNav("Server","⌁   SERVER")
makeNav("Performance","⚡   PERFORMANCE")
makeNav("Tools","＋   TOOLS")
makeNav("Settings","⚙   SETTINGS")

--========================================================
-- COMPONENTS
--========================================================
local ControlRegistry = {}

local function registerControl(parent,text,frame)
    if not parent or not frame or not text then return end
    table.insert(ControlRegistry,{
        Text=tostring(text),
        Page=parent.Name,
        Frame=frame
    })
end

local function heading(parent, title, subtitle)
    local wrap = Instance.new("Frame")
    wrap.Size = UDim2.new(1,0,0,subtitle and 58 or 38)
    wrap.BackgroundTransparency = 1
    wrap.ZIndex = 10
    wrap.Parent = parent

    local t = Instance.new("TextLabel")
    t.Size = UDim2.new(1,0,0,34)
    t.BackgroundTransparency = 1
    t.Text = title
    t.TextColor3 = C.White
    t.TextSize = 19
    t.TextXAlignment = Enum.TextXAlignment.Left
    t.Font = Enum.Font.GothamBold
    t.ZIndex = 11
    t.Parent = wrap

    if subtitle then
        local s = Instance.new("TextLabel")
        s.Size = UDim2.new(1,0,0,22)
        s.Position = UDim2.fromOffset(0,32)
        s.BackgroundTransparency = 1
        s.Text = subtitle
        s.TextColor3 = C.Soft
        s.TextSize = 11
        s.TextXAlignment = Enum.TextXAlignment.Left
        s.Font = Enum.Font.Gotham
        s.ZIndex = 11
        s.Parent = wrap
    end
    return wrap
end

local function section(parent, text)
    local l = Instance.new("TextLabel")
    l.Size = UDim2.new(1,0,0,28)
    l.BackgroundTransparency = 1
    l.Text = "✦  "..text
    l.TextColor3 = C.Cyan
    l.TextSize = 13
    l.TextXAlignment = Enum.TextXAlignment.Left
    l.Font = Enum.Font.GothamBold
    l.ZIndex = 11
    l.Parent = parent
    return l
end

local function card(parent, height)
    local f = Instance.new("Frame")
    f.Size = UDim2.new(1,0,0,height or 54)
    f.BackgroundColor3 = C.Panel
    f.BackgroundTransparency = .04
    f.ZIndex = 10
    f.Parent = parent
    corner(f,12)
    stroke(f,C.Purple,1,.72)
    return f
end

local function infoCard(parent, title, text)
    local f = card(parent,86)

    local t = Instance.new("TextLabel")
    t.Size = UDim2.new(1,-20,0,26)
    t.Position = UDim2.fromOffset(10,8)
    t.BackgroundTransparency = 1
    t.Text = title
    t.TextColor3 = C.White
    t.TextSize = 14
    t.TextXAlignment = Enum.TextXAlignment.Left
    t.Font = Enum.Font.GothamBold
    t.ZIndex = 11
    t.Parent = f

    local d = Instance.new("TextLabel")
    d.Size = UDim2.new(1,-20,1,-39)
    d.Position = UDim2.fromOffset(10,34)
    d.BackgroundTransparency = 1
    d.Text = text
    d.TextColor3 = C.Soft
    d.TextSize = 11
    d.TextWrapped = true
    d.TextXAlignment = Enum.TextXAlignment.Left
    d.TextYAlignment = Enum.TextYAlignment.Top
    d.Font = Enum.Font.Gotham
    d.ZIndex = 11
    d.Parent = f

    return f,d
end

local function button(parent, text, callback)
    local f = card(parent,52)
    local b = Instance.new("TextButton")
    b.Size = UDim2.new(1,-14,1,-14)
    b.Position = UDim2.fromOffset(7,7)
    b.BackgroundColor3 = C.Panel2
    b.Text = text
    b.TextColor3 = C.White
    b.TextSize = 12
    b.Font = Enum.Font.GothamSemibold
    b.AutoButtonColor = false
    b.ZIndex = 11
    b.Parent = f
    corner(b,10)
    registerControl(parent,text,f)

    b.MouseButton1Click:Connect(function()
        TweenService:Create(b,TweenInfo.new(.07),{BackgroundColor3=C.PurpleDark}):Play()
        task.delay(.12,function()
            if b.Parent then
                TweenService:Create(b,TweenInfo.new(.13),{BackgroundColor3=C.Panel2}):Play()
            end
        end)
        if callback then callback(b) end
    end)

    return b,f
end

local function toggle(parent, text, default, callback)
    local state = not not default
    local f = card(parent,54)

    local l = Instance.new("TextLabel")
    l.Size = UDim2.new(1,-90,1,0)
    l.Position = UDim2.fromOffset(12,0)
    l.BackgroundTransparency = 1
    l.Text = text
    l.TextColor3 = C.White
    l.TextSize = 12
    l.TextXAlignment = Enum.TextXAlignment.Left
    l.Font = Enum.Font.GothamSemibold
    l.ZIndex = 11
    l.Parent = f

    local b = Instance.new("TextButton")
    b.Size = UDim2.fromOffset(60,30)
    b.Position = UDim2.new(1,-72,.5,-15)
    b.BackgroundColor3 = state and C.Purple or C.Black
    b.Text = state and "ON" or "OFF"
    b.TextColor3 = C.White
    b.TextSize = 10
    b.Font = Enum.Font.GothamBold
    b.AutoButtonColor = false
    b.ZIndex = 11
    b.Parent = f
    corner(b,12)
    registerControl(parent,text,f)

    local function render()
        b.Text = state and "ON" or "OFF"
        TweenService:Create(b,TweenInfo.new(.14),{
            BackgroundColor3 = state and C.Purple or C.Black
        }):Play()
    end

    b.MouseButton1Click:Connect(function()
        state = not state
        render()
        if callback then callback(state) end
    end)

    return {
        Frame = f,
        Label = l,
        Button = b,
        Get = function() return state end,
        Set = function(v)
            state = not not v
            render()
            if callback then callback(state) end
        end
    }
end

local function slider(parent, text, minv, maxv, default, callback)
    local value = default
    local f = card(parent,72)

    local l = Instance.new("TextLabel")
    l.Size = UDim2.new(1,-84,0,28)
    l.Position = UDim2.fromOffset(12,4)
    l.BackgroundTransparency = 1
    l.Text = text
    l.TextColor3 = C.White
    l.TextSize = 12
    l.TextXAlignment = Enum.TextXAlignment.Left
    l.Font = Enum.Font.GothamSemibold
    l.ZIndex = 11
    l.Parent = f

    local val = Instance.new("TextLabel")
    val.Size = UDim2.fromOffset(66,28)
    val.Position = UDim2.new(1,-78,0,4)
    val.BackgroundTransparency = 1
    val.Text = tostring(default)
    val.TextColor3 = C.Cyan
    val.TextSize = 12
    val.Font = Enum.Font.GothamBold
    val.ZIndex = 11
    val.Parent = f

    local bar = Instance.new("Frame")
    bar.Size = UDim2.new(1,-26,0,9)
    bar.Position = UDim2.fromOffset(13,48)
    bar.BackgroundColor3 = C.Black
    bar.ZIndex = 11
    bar.Parent = f
    corner(bar,8)

    local pct0 = (default-minv)/(maxv-minv)

    local fill = Instance.new("Frame")
    fill.Size = UDim2.new(pct0,0,1,0)
    fill.BackgroundColor3 = C.Purple
    fill.ZIndex = 12
    fill.Parent = bar
    corner(fill,8)
    gradient(fill,C.Purple,C.Blue,0)

    local knob = Instance.new("Frame")
    knob.Size = UDim2.fromOffset(18,18)
    knob.AnchorPoint = Vector2.new(.5,.5)
    knob.Position = UDim2.new(pct0,0,.5,0)
    knob.BackgroundColor3 = C.White
    knob.ZIndex = 13
    knob.Parent = bar
    corner(knob,9)
    stroke(knob,C.Purple,1,.1)

    registerControl(parent,text,f)

    local dragging = false

    local function setX(x)
        local pct = math.clamp((x-bar.AbsolutePosition.X)/math.max(1,bar.AbsoluteSize.X),0,1)
        value = math.floor(minv + (maxv-minv)*pct + .5)
        fill.Size = UDim2.new(pct,0,1,0)
        knob.Position = UDim2.new(pct,0,.5,0)
        val.Text = tostring(value)
        if callback then callback(value) end
    end

    bar.InputBegan:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.Touch
        or input.UserInputType == Enum.UserInputType.MouseButton1 then
            dragging = true
            setX(input.Position.X)
        end
    end)

    UIS.InputChanged:Connect(function(input)
        if dragging and (
            input.UserInputType == Enum.UserInputType.Touch
            or input.UserInputType == Enum.UserInputType.MouseMovement
        ) then
            setX(input.Position.X)
        end
    end)

    UIS.InputEnded:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.Touch
        or input.UserInputType == Enum.UserInputType.MouseButton1 then
            dragging = false
        end
    end)

    return {
        Frame = f,
        Label = l,
        Get = function() return value end,
        Set = function(v)
            value = math.clamp(math.floor(v + .5),minv,maxv)
            local pct = (value-minv)/(maxv-minv)
            fill.Size = UDim2.new(pct,0,1,0)
            knob.Position = UDim2.new(pct,0,.5,0)
            val.Text = tostring(value)
            if callback then callback(value) end
        end
    }
end

--========================================================
-- PLAYER PICKER (dynamic current server list)
--========================================================
local ModalDim = Instance.new("TextButton")
ModalDim.Size = UDim2.fromScale(1,1)
ModalDim.BackgroundColor3 = Color3.new(0,0,0)
ModalDim.BackgroundTransparency = .42
ModalDim.Text = ""
ModalDim.AutoButtonColor = false
ModalDim.Visible = false
ModalDim.ZIndex = 150
ModalDim.Parent = Gui

local function playerPicker(title, allowAll, callback)
    ModalDim.Visible = true

    local modal = Instance.new("Frame")
    modal.Size = UDim2.fromOffset(350,350)
    modal.Position = UDim2.fromScale(.5,.5)
    modal.AnchorPoint = Vector2.new(.5,.5)
    modal.BackgroundColor3 = C.Space2
    modal.ZIndex = 151
    modal.Parent = Gui
    corner(modal,17)
    stroke(modal,C.Purple,1.5,.08)

    local ttl = Instance.new("TextLabel")
    ttl.Size = UDim2.new(1,-54,0,48)
    ttl.Position = UDim2.fromOffset(12,0)
    ttl.BackgroundTransparency = 1
    ttl.Text = title
    ttl.TextColor3 = C.White
    ttl.TextSize = 16
    ttl.TextXAlignment = Enum.TextXAlignment.Left
    ttl.Font = Enum.Font.GothamBold
    ttl.ZIndex = 152
    ttl.Parent = modal

    local close = Instance.new("TextButton")
    close.Size = UDim2.fromOffset(36,32)
    close.Position = UDim2.new(1,-44,0,8)
    close.BackgroundColor3 = C.Panel2
    close.Text = "×"
    close.TextColor3 = C.White
    close.TextSize = 18
    close.Font = Enum.Font.GothamBold
    close.ZIndex = 152
    close.Parent = modal
    corner(close,10)

    local list = Instance.new("ScrollingFrame")
    list.Size = UDim2.new(1,-20,1,-62)
    list.Position = UDim2.fromOffset(10,52)
    list.BackgroundTransparency = 1
    list.BorderSizePixel = 0
    list.AutomaticCanvasSize = Enum.AutomaticSize.Y
    list.CanvasSize = UDim2.fromOffset(0,0)
    list.ScrollBarThickness = 3
    list.ScrollBarImageColor3 = C.Purple
    list.ZIndex = 152
    list.Parent = modal

    local ll = Instance.new("UIListLayout")
    ll.Padding = UDim.new(0,7)
    ll.Parent = list

    local function dismiss()
        ModalDim.Visible = false
        if modal then modal:Destroy() end
    end

    close.MouseButton1Click:Connect(dismiss)

    local function addChoice(text, p)
        local b = Instance.new("TextButton")
        b.Size = UDim2.new(1,-5,0,44)
        b.BackgroundColor3 = C.Panel
        b.Text = text
        b.TextColor3 = C.White
        b.TextSize = 12
        b.Font = Enum.Font.GothamSemibold
        b.AutoButtonColor = false
        b.ZIndex = 153
        b.Parent = list
        corner(b,10)
        b.MouseButton1Click:Connect(function()
            dismiss()
            callback(p)
        end)
    end

    if allowAll then
        addChoice("★  Tutti / Everyone", nil)
    end

    for _,p in ipairs(Players:GetPlayers()) do
        if p ~= LP then
            addChoice(p.DisplayName.."   @"..p.Name, p)
        end
    end
end



--========================================================
-- SHARED CONTEXT FOR ULTRANOVA MODULES
--========================================================
local UltraNovaGlobal = (getgenv and getgenv()) or _G
local U = {
    Players=Players, UIS=UIS, RunService=RunService, TweenService=TweenService,
    Lighting=Lighting, SoundService=SoundService, TeleportService=TeleportService,
    MarketplaceService=MarketplaceService, GuiService=GuiService, VirtualUser=VirtualUser,
    CoreGui=CoreGui, HttpService=HttpService, Stats=Stats, ContentProvider=ContentProvider,
    StarterGui=StarterGui, LP=LP, Camera=Camera, unpackArgs=unpackArgs,

    character=character, humanoid=humanoid, root=root,
    GuiParent=GuiParent, C=C, ESP_PALETTE=ESP_PALETTE,
    corner=corner, stroke=stroke, gradient=gradient, padding=padding,
    S=S, original=original,

    Gui=Gui, Main=Main, Scale=Scale, refreshScale=refreshScale, Stars=Stars,
    MainLineFX=MainLineFX, restartMainLineTweens=restartMainLineTweens,
    Header=Header, NovaIcon=NovaIcon, Title=Title, SubTitle=SubTitle,
    Minimize=Minimize, Mini=Mini, MiniLineFX=MiniLineFX,
    restartMiniLineTweens=restartMiniLineTweens,
    toast=toast,

    MenuAmbience=MenuAmbience, MenuWhoosh=MenuWhoosh, syncMenuAudio=syncMenuAudio,
    Sidebar=Sidebar, SideList=SideList, Content=Content, Pages=Pages, Navs=Navs,
    makePage=makePage, switchPage=switchPage,
    Home=Home, Cheats=Cheats, PlayersPage=PlayersPage, CameraPage=CameraPage,
    VisualsPage=VisualsPage, Emotes=Emotes, Shaders=Shaders, ServerPage=ServerPage,
    PerformancePage=PerformancePage, ToolsPage=ToolsPage, SettingsPage=SettingsPage,

    ControlRegistry=ControlRegistry, registerControl=registerControl,
    heading=heading, section=section, card=card, infoCard=infoCard,
    button=button, toggle=toggle, slider=slider,
    ModalDim=ModalDim, playerPicker=playerPicker,

    isMiniDragging=function() return miniDragging end,
    isMiniMoved=function() return miniMoved end,
    setMiniMoved=function(v) miniMoved=v end,
}
UltraNovaGlobal.UltraNovaV32 = U
