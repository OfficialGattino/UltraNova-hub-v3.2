--[[
    UltraNova Hub v3.2 — Modular Loader
    Created by OfficialGattino

    This loader keeps UltraNova split into smaller Luau chunks so the
    executor does not hit Luau's local-register limit.
]]

local BASE = "https://raw.githubusercontent.com/OfficialGattino/UltraNova-hub-v3.2/main/"
local FILES = {
    "UltraNova_v3_2_core.lua",
    "UltraNova_v3_2_movement.lua",
    "UltraNova_v3_2_combat_visuals.lua",
    "UltraNova_v3_2_emotes.lua",
    "UltraNova_v3_2_shaders.lua",
    "UltraNova_v3_2_players.lua",
    "UltraNova_v3_2_camera_visuals.lua",
    "UltraNova_v3_2_server_tools.lua",
    "UltraNova_v3_2_settings.lua",
    "UltraNova_v3_2_lifecycle.lua",
}

local Players = game:GetService("Players")
local StarterGui = game:GetService("StarterGui")
local LP = Players.LocalPlayer

local function showFatal(title,text)
    pcall(function()
        StarterGui:SetCore("SendNotification",{Title=title,Text=text,Duration=8})
    end)

    pcall(function()
        local old=LP:WaitForChild("PlayerGui"):FindFirstChild("UltraNovaLoaderError")
        if old then old:Destroy() end
        local g=Instance.new("ScreenGui")
        g.Name="UltraNovaLoaderError"; g.ResetOnSpawn=false; g.Parent=LP.PlayerGui
        local f=Instance.new("Frame")
        f.Size=UDim2.new(.86,0,0,170); f.Position=UDim2.new(.07,0,.5,-85)
        f.BackgroundColor3=Color3.fromRGB(11,7,27); f.Parent=g
        Instance.new("UICorner",f).CornerRadius=UDim.new(0,16)
        local s=Instance.new("UIStroke",f); s.Color=Color3.fromRGB(151,77,255); s.Thickness=1.4
        local l=Instance.new("TextLabel")
        l.Size=UDim2.new(1,-24,1,-24); l.Position=UDim2.fromOffset(12,12)
        l.BackgroundTransparency=1; l.TextColor3=Color3.new(1,1,1)
        l.TextWrapped=true; l.TextScaled=false; l.TextSize=15; l.Font=Enum.Font.GothamBold
        l.Text=title.."\n\n"..text; l.Parent=f
    end)
end

local env=(getgenv and getgenv()) or _G
env.UltraNovaV32=nil

for index,path in ipairs(FILES) do
    local okDownload,source=pcall(function()
        return game:HttpGet(BASE..path)
    end)
    if not okDownload then
        local msg="Download failed: "..path.."\n"..tostring(source)
        showFatal("UltraNova v3.2",msg)
        error(msg)
    end

    local chunk,compileError=loadstring(source,"@UltraNova/"..path)
    if not chunk then
        local msg="Compile error in "..path.."\n"..tostring(compileError)
        showFatal("UltraNova v3.2",msg)
        error(msg)
    end

    local okRun,runError=xpcall(chunk,function(e)
        return tostring(e)
    end)
    if not okRun then
        local msg="Runtime error in "..path.."\n"..tostring(runError)
        showFatal("UltraNova v3.2",msg)
        error(msg)
    end

    if index < #FILES then task.wait() end
end
