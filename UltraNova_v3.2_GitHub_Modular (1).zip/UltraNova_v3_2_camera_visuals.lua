local UltraNovaGlobal = (getgenv and getgenv()) or _G
local U = assert(UltraNovaGlobal.UltraNovaV32, "UltraNova v3.2 core was not loaded")
local Players,UIS,RunService,TweenService,Lighting,SoundService,TeleportService,MarketplaceService,GuiService,VirtualUser,CoreGui,HttpService,Stats,ContentProvider,StarterGui = U.Players,U.UIS,U.RunService,U.TweenService,U.Lighting,U.SoundService,U.TeleportService,U.MarketplaceService,U.GuiService,U.VirtualUser,U.CoreGui,U.HttpService,U.Stats,U.ContentProvider,U.StarterGui
local LP,Camera,unpackArgs = U.LP,U.Camera,U.unpackArgs
local character,humanoid,root = U.character,U.humanoid,U.root
local GuiParent,C,ESP_PALETTE = U.GuiParent,U.C,U.ESP_PALETTE
local corner,stroke,gradient,padding = U.corner,U.stroke,U.gradient,U.padding
local S,original = U.S,U.original
local Gui,Main,Scale,refreshScale,Stars = U.Gui,U.Main,U.Scale,U.refreshScale,U.Stars
local MainLineFX,restartMainLineTweens = U.MainLineFX,U.restartMainLineTweens
local Header,NovaIcon,Title,SubTitle,Minimize,Mini,MiniLineFX,restartMiniLineTweens = U.Header,U.NovaIcon,U.Title,U.SubTitle,U.Minimize,U.Mini,U.MiniLineFX,U.restartMiniLineTweens
local toast = U.toast
local MenuAmbience,MenuWhoosh,syncMenuAudio = U.MenuAmbience,U.MenuWhoosh,U.syncMenuAudio
local Sidebar,SideList,Content,Pages,Navs = U.Sidebar,U.SideList,U.Content,U.Pages,U.Navs
local makePage,switchPage = U.makePage,U.switchPage
local Home,Cheats,PlayersPage,CameraPage,VisualsPage,Emotes,Shaders,ServerPage,PerformancePage,ToolsPage,SettingsPage = U.Home,U.Cheats,U.PlayersPage,U.CameraPage,U.VisualsPage,U.Emotes,U.Shaders,U.ServerPage,U.PerformancePage,U.ToolsPage,U.SettingsPage
local ControlRegistry,registerControl = U.ControlRegistry,U.registerControl
local heading,section,card,infoCard,button,toggle,slider = U.heading,U.section,U.card,U.infoCard,U.button,U.toggle,U.slider
local ModalDim,playerPicker = U.ModalDim,U.playerPicker

--========================================================
-- CAMERA PAGE
--========================================================
heading(CameraPage,"CAMERA","Freecam • Zoom • Follow • Screenshot")

local FreeCamPad=Instance.new("Frame")
FreeCamPad.Size=UDim2.fromOffset(190,145); FreeCamPad.Position=UDim2.new(1,-205,1,-165); FreeCamPad.BackgroundColor3=C.Space2; FreeCamPad.BackgroundTransparency=.18; FreeCamPad.Visible=false; FreeCamPad.ZIndex=88; FreeCamPad.Parent=Gui
corner(FreeCamPad,16); stroke(FreeCamPad,C.Purple,1,.2)
local FreeInput={F=0,R=0,U=0,Yaw=0}
local freeCFrame=nil

local function camPadButton(text,x,y,w,h,field,val)
    local b=Instance.new("TextButton"); b.Size=UDim2.fromOffset(w or 42,h or 42); b.Position=UDim2.fromOffset(x,y); b.BackgroundColor3=C.Panel2; b.Text=text; b.TextColor3=C.White; b.TextSize=16; b.Font=Enum.Font.GothamBold; b.ZIndex=89; b.Parent=FreeCamPad; corner(b,10)
    b.InputBegan:Connect(function(i) if i.UserInputType==Enum.UserInputType.Touch or i.UserInputType==Enum.UserInputType.MouseButton1 then FreeInput[field]=val end end)
    b.InputEnded:Connect(function(i) if i.UserInputType==Enum.UserInputType.Touch or i.UserInputType==Enum.UserInputType.MouseButton1 then if FreeInput[field]==val then FreeInput[field]=0 end end end)
end
camPadButton("▲",50,8,42,42,"F",1); camPadButton("▼",50,94,42,42,"F",-1)
camPadButton("◀",6,51,42,42,"R",-1); camPadButton("▶",94,51,42,42,"R",1)
camPadButton("＋",140,8,42,42,"U",1); camPadButton("－",140,94,42,42,"U",-1)
camPadButton("↶",6,8,42,32,"Yaw",-1); camPadButton("↷",94,8,42,32,"Yaw",1)

local function setFreecam(on)
    S.freecam=on
    FreeCamPad.Visible=on
    if on then
        freeCFrame=Camera.CFrame; Camera.CameraType=Enum.CameraType.Scriptable
    else
        Camera.CameraType=Enum.CameraType.Custom
        local h=humanoid(); if h then Camera.CameraSubject=h end
    end
end

toggle(CameraPage,"Freecam",false,setFreecam)
slider(CameraPage,"Velocità Freecam / Freecam Speed",5,120,28,function(v) S.freecamSpeed=v end)

RunService.RenderStepped:Connect(function(dt)
    if S.freecam then
        Camera.CameraType=Enum.CameraType.Scriptable
        freeCFrame=freeCFrame or Camera.CFrame
        freeCFrame=freeCFrame*CFrame.Angles(0,math.rad(FreeInput.Yaw*70*dt),0)
        local move=freeCFrame.LookVector*FreeInput.F + freeCFrame.RightVector*FreeInput.R + Vector3.new(0,FreeInput.U,0)
        if move.Magnitude>0 then freeCFrame=freeCFrame+CFrame.new(move.Unit*S.freecamSpeed*dt).Position end
        Camera.CFrame=freeCFrame
    elseif math.abs(S.cameraRoll)>.05 then
        Camera.CFrame=Camera.CFrame*CFrame.Angles(0,0,math.rad(S.cameraRoll))
    end
end)

button(CameraPage,"Zoom +",function() Camera.FieldOfView=math.max(40,Camera.FieldOfView-5); S.fov=Camera.FieldOfView end)
button(CameraPage,"Zoom -",function() Camera.FieldOfView=math.min(120,Camera.FieldOfView+5); S.fov=Camera.FieldOfView end)

toggle(CameraPage,"Prima persona / First Person Lock",false,function(on)
    LP.CameraMode=on and Enum.CameraMode.LockFirstPerson or Enum.CameraMode.Classic
end)

slider(CameraPage,"Distanza terza persona / Third Person",4,40,12,function(v)
    S.thirdPersonDistance=v
    LP.CameraMaxZoomDistance=v
    if LP.CameraMinZoomDistance>v then LP.CameraMinZoomDistance=0.5 end
end)

slider(CameraPage,"Camera Roll",-15,15,0,function(v) S.cameraRoll=v end)

local CineFov={60,70,80,90}; local CineFovIndex=1
button(CameraPage,"Cinematic FOV: 60",function(b)
    CineFovIndex=CineFovIndex%#CineFov+1; local v=CineFov[CineFovIndex]; Camera.FieldOfView=v; S.fov=v; b.Text="Cinematic FOV: "..v
end)

button(CameraPage,"Segui giocatore / Camera Follow",function()
    playerPicker("Camera Follow",false,function(p)
        local h=p.Character and p.Character:FindFirstChildOfClass("Humanoid")
        if h then setFreecam(false); Camera.CameraSubject=h end
    end)
end)

button(CameraPage,"Torna a me / Follow Myself",function()
    local h=humanoid(); if h then setFreecam(false); Camera.CameraSubject=h end
end)

local ScreenshotMode=false
button(CameraPage,"Screenshot Mode / Hide Roblox HUD",function(b)
    ScreenshotMode=not ScreenshotMode
    pcall(function() StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.All,not ScreenshotMode) end)
    b.Text=ScreenshotMode and "Screenshot Mode: ON" or "Screenshot Mode / Hide Roblox HUD"
    if ScreenshotMode then Main.Visible=false; Mini.Visible=true end
end)

--========================================================
-- VISUALS PAGE
--========================================================
heading(VisualsPage,"VISUALS","Tracers • Boxes • Skeleton • Chams • Crosshair+")

local ExtraVisualGui=Instance.new("ScreenGui")
ExtraVisualGui.Name="UltraNovaExtraVisuals"; ExtraVisualGui.IgnoreGuiInset=true; ExtraVisualGui.ResetOnSpawn=false; ExtraVisualGui.ZIndexBehavior=Enum.ZIndexBehavior.Sibling; ExtraVisualGui.Parent=GuiParent
local ExtraVisualObjects={}
local VisualWorldFolder=Instance.new("Folder")
VisualWorldFolder.Name="UltraNovaVisualWorld"
VisualWorldFolder.Parent=workspace

local function getVisualObj(p)
    local o=ExtraVisualObjects[p]
    if o then return o end
    o={}
    o.Tracer=Instance.new("Frame"); o.Tracer.AnchorPoint=Vector2.new(0,.5); o.Tracer.BackgroundColor3=C.Purple; o.Tracer.BorderSizePixel=0; o.Tracer.Visible=false; o.Tracer.ZIndex=35; o.Tracer.Parent=ExtraVisualGui
    o.Box=Instance.new("Frame"); o.Box.BackgroundTransparency=1; o.Box.Visible=false; o.Box.ZIndex=35; o.Box.Parent=ExtraVisualGui; o.BoxStroke=stroke(o.Box,C.Purple,1.3,.05)
    o.HealthBG=Instance.new("Frame"); o.HealthBG.BackgroundColor3=C.Black; o.HealthBG.BorderSizePixel=0; o.HealthBG.Visible=false; o.HealthBG.ZIndex=36; o.HealthBG.Parent=ExtraVisualGui
    o.Health=Instance.new("Frame"); o.Health.BackgroundColor3=C.Green; o.Health.BorderSizePixel=0; o.Health.AnchorPoint=Vector2.new(0,1); o.Health.Position=UDim2.new(0,0,1,0); o.Health.Size=UDim2.fromScale(1,1); o.Health.ZIndex=37; o.Health.Parent=o.HealthBG
    o.HL=Instance.new("Highlight"); o.HL.Enabled=false; o.HL.DepthMode=Enum.HighlightDepthMode.AlwaysOnTop; o.HL.Parent=VisualWorldFolder
    o.Skel={}
    for i=1,12 do local f=Instance.new("Frame"); f.AnchorPoint=Vector2.new(0,.5); f.BorderSizePixel=0; f.BackgroundColor3=C.Cyan; f.Visible=false; f.ZIndex=34; f.Parent=ExtraVisualGui; o.Skel[i]=f end
    ExtraVisualObjects[p]=o; return o
end

local function draw2DLine(frame,a,b,color,thickness)
    local d=b-a; local len=d.Magnitude
    frame.Position=UDim2.fromOffset(a.X,a.Y); frame.Size=UDim2.fromOffset(len,thickness or 1); frame.Rotation=math.deg(math.atan2(d.Y,d.X)); frame.BackgroundColor3=color; frame.Visible=true
end

local function hideVisual(o)
    o.Tracer.Visible=false; o.Box.Visible=false; o.HealthBG.Visible=false; o.HL.Enabled=false
    for _,f in ipairs(o.Skel) do f.Visible=false end
end

toggle(VisualsPage,"Tracers",false,function(on) S.tracers=on end)
toggle(VisualsPage,"Box ESP",false,function(on) S.boxEsp=on end)
toggle(VisualsPage,"Health Bar ESP",false,function(on) S.healthBars=on end)
toggle(VisualsPage,"Skeleton ESP",false,function(on) S.skeletonEsp=on end)
toggle(VisualsPage,"Chams",false,function(on) S.chams=on end)
toggle(VisualsPage,"Player Glow",false,function(on) S.playerGlow=on end)
toggle(VisualsPage,"Rainbow ESP",false,function(on) S.rainbowEsp=on end)
slider(VisualsPage,"Distanza massima ESP / Max ESP Distance",100,5000,2500,function(v) S.espMaxDistance=v end)

toggle(VisualsPage,"Night Vision",false,function(on)
    S.nightVision=on
    local old=Lighting:FindFirstChild("UltraNovaNightVision"); if old then old:Destroy() end
    if on then
        local cc=Instance.new("ColorCorrectionEffect"); cc.Name="UltraNovaNightVision"; cc.TintColor=Color3.fromRGB(190,255,205); cc.Brightness=.12; cc.Contrast=.08; cc.Saturation=-.08; cc.Parent=Lighting
    end
end)

section(VisualsPage,"CROSSHAIR+")
button(VisualsPage,"Colore crosshair / Crosshair Color",function(b)
    S.crosshairColorIndex=S.crosshairColorIndex%#ESP_PALETTE+1
    local col=ESP_PALETTE[S.crosshairColorIndex]
    CrossH.BackgroundColor3=col; CrossV.BackgroundColor3=col; CrossDot.BackgroundColor3=col; b.TextColor3=col
end)
slider(VisualsPage,"Spessore crosshair / Thickness",1,8,2,function(v)
    S.crosshairThickness=v; CrossH.Size=UDim2.fromOffset(S.crosshairSize,v); CrossV.Size=UDim2.fromOffset(v,S.crosshairSize)
end)
slider(VisualsPage,"Trasparenza crosshair / Opacity",0,90,0,function(v)
    S.crosshairOpacity=v/100; CrossH.BackgroundTransparency=S.crosshairOpacity; CrossV.BackgroundTransparency=S.crosshairOpacity; CrossDot.BackgroundTransparency=S.crosshairOpacity
end)

local skeletonPairsR15={{"Head","UpperTorso"},{"UpperTorso","LowerTorso"},{"UpperTorso","LeftUpperArm"},{"LeftUpperArm","LeftLowerArm"},{"LeftLowerArm","LeftHand"},{"UpperTorso","RightUpperArm"},{"RightUpperArm","RightLowerArm"},{"RightLowerArm","RightHand"},{"LowerTorso","LeftUpperLeg"},{"LeftUpperLeg","LeftLowerLeg"},{"LowerTorso","RightUpperLeg"},{"RightUpperLeg","RightLowerLeg"}}
local skeletonPairsR6={{"Head","Torso"},{"Torso","Left Arm"},{"Torso","Right Arm"},{"Torso","Left Leg"},{"Torso","Right Leg"}}

RunService.RenderStepped:Connect(function()
    Camera=workspace.CurrentCamera or Camera
    local myRoot=root(); local centerBottom=Vector2.new(Camera.ViewportSize.X/2,Camera.ViewportSize.Y-5)
    local rainbow=Color3.fromHSV((os.clock()*.13)%1,.85,1)
    if S.rainbowEsp then S.espColor=rainbow end

    for _,p in ipairs(Players:GetPlayers()) do
        if p~=LP then
            local o=getVisualObj(p); local c=p.Character; local pr=c and c:FindFirstChild("HumanoidRootPart"); local head=c and c:FindFirstChild("Head"); local h=c and c:FindFirstChildOfClass("Humanoid")
            local allowed=false; local distance=math.huge
            if pr and myRoot then distance=(pr.Position-myRoot.Position).Magnitude; allowed=distance<=S.espMaxDistance end
            if not allowed then hideVisual(o) else
                local col=S.rainbowEsp and rainbow or S.espColor
                local rp,ron=Camera:WorldToViewportPoint(pr.Position); local hp,hon=head and Camera:WorldToViewportPoint(head.Position) or rp,false
                if ron and rp.Z>0 then
                    if S.tracers then draw2DLine(o.Tracer,centerBottom,Vector2.new(rp.X,rp.Y),col,1.4) else o.Tracer.Visible=false end
                    local height=math.max(28,math.abs(rp.Y-hp.Y)*2.7); local width=height*.55
                    if S.boxEsp then o.Box.Position=UDim2.fromOffset(rp.X-width/2,rp.Y-height/2); o.Box.Size=UDim2.fromOffset(width,height); o.BoxStroke.Color=col; o.Box.Visible=true else o.Box.Visible=false end
                    if S.healthBars and h then
                        o.HealthBG.Position=UDim2.fromOffset(rp.X-width/2-7,rp.Y-height/2); o.HealthBG.Size=UDim2.fromOffset(4,height); o.Health.Size=UDim2.new(1,0,math.clamp(h.Health/math.max(1,h.MaxHealth),0,1),0); o.HealthBG.Visible=true
                    else o.HealthBG.Visible=false end
                    o.HL.Adornee=c; o.HL.FillColor=col; o.HL.OutlineColor=col; o.HL.FillTransparency=S.chams and .68 or 1; o.HL.OutlineTransparency=S.playerGlow and 0 or .45; o.HL.Enabled=S.chams or S.playerGlow
                    for _,f in ipairs(o.Skel) do f.Visible=false end
                    if S.skeletonEsp then
                        local pairsList=(h and h.RigType==Enum.HumanoidRigType.R15) and skeletonPairsR15 or skeletonPairsR6
                        for i,pair in ipairs(pairsList) do
                            local a=c:FindFirstChild(pair[1]); local b=c:FindFirstChild(pair[2]); local f=o.Skel[i]
                            if a and b and f then local ap,aon=Camera:WorldToViewportPoint(a.Position); local bp,bon=Camera:WorldToViewportPoint(b.Position); if aon and bon then draw2DLine(f,Vector2.new(ap.X,ap.Y),Vector2.new(bp.X,bp.Y),col,1.2) end end
                        end
                    end
                else hideVisual(o) end
            end
        end
    end
end)

Players.PlayerRemoving:Connect(function(p)
    local o=ExtraVisualObjects[p]; if o then pcall(function() o.Tracer:Destroy(); o.Box:Destroy(); o.HealthBG:Destroy(); o.HL:Destroy(); for _,f in ipairs(o.Skel) do f:Destroy() end end); ExtraVisualObjects[p]=nil end
end)

--========================================================
-- SHADERS WORLD FX ADD-ON
--========================================================
section(Shaders,"WORLD FX / SCENE CONTROL")
local Terrain=workspace:FindFirstChildOfClass("Terrain")
local OriginalWater = Terrain and {Color=Terrain.WaterColor,Transparency=Terrain.WaterTransparency,WaveSize=Terrain.WaterWaveSize,WaveSpeed=Terrain.WaterWaveSpeed,Reflectance=Terrain.WaterReflectance} or nil
local Clouds=Terrain and Terrain:FindFirstChildOfClass("Clouds")

button(Shaders,"Acqua: Realistic / Water",function()
    if Terrain then Terrain.WaterColor=Color3.fromRGB(34,104,145); Terrain.WaterTransparency=.22; Terrain.WaterReflectance=.45; Terrain.WaterWaveSize=.18; Terrain.WaterWaveSpeed=12 end
end)
button(Shaders,"Acqua: Deep Space",function()
    if Terrain then Terrain.WaterColor=Color3.fromRGB(39,20,86); Terrain.WaterTransparency=.28; Terrain.WaterReflectance=.55; Terrain.WaterWaveSize=.14; Terrain.WaterWaveSpeed=8 end
end)
button(Shaders,"Reset Acqua / Reset Water",function()
    if Terrain and OriginalWater then Terrain.WaterColor=OriginalWater.Color; Terrain.WaterTransparency=OriginalWater.Transparency; Terrain.WaterReflectance=OriginalWater.Reflectance; Terrain.WaterWaveSize=OriginalWater.WaveSize; Terrain.WaterWaveSpeed=OriginalWater.WaveSpeed end
end)
slider(Shaders,"Ora del giorno / Time of Day",0,24,math.floor(Lighting.ClockTime),function(v) Lighting.ClockTime=v end)
slider(Shaders,"Atmosphere Contrast",0,50,10,function(v)
    local cc=Lighting:FindFirstChild("UltraNovaManualContrast") or Instance.new("ColorCorrectionEffect"); cc.Name="UltraNovaManualContrast"; cc.Parent=Lighting; cc.Contrast=v/100
end)
slider(Shaders,"Saturazione / Saturation",0,200,100,function(v)
    local cc=Lighting:FindFirstChild("UltraNovaManualSaturation") or Instance.new("ColorCorrectionEffect"); cc.Name="UltraNovaManualSaturation"; cc.Parent=Lighting; cc.Saturation=(v-100)/100
end)
button(Shaders,"Nuvole cinematiche / Cinematic Clouds",function()
    if Terrain then
        Clouds=Terrain:FindFirstChildOfClass("Clouds") or Instance.new("Clouds",Terrain); Clouds.Cover=.48; Clouds.Density=.55; Clouds.Color=Color3.fromRGB(220,214,238)
    end
end)
button(Shaders,"Nuvole space / Space Clouds",function()
    if Terrain then
        Clouds=Terrain:FindFirstChildOfClass("Clouds") or Instance.new("Clouds",Terrain); Clouds.Cover=.62; Clouds.Density=.66; Clouds.Color=Color3.fromRGB(92,63,142)
    end
end)



U.FreeCamPad = FreeCamPad
U.setFreecam = setFreecam
U.ExtraVisualGui = ExtraVisualGui
U.VisualWorldFolder = VisualWorldFolder
