local UltraNovaGlobal = (getgenv and getgenv()) or _G
local U = assert(UltraNovaGlobal.UltraNovaV32, "UltraNova v3.2 core was not loaded")
local Players,UIS,RunService,TweenService,Lighting,SoundService,TeleportService,MarketplaceService,GuiService,VirtualUser,CoreGui,HttpService,Stats,ContentProvider,StarterGui = U.Players,U.UIS,U.RunService,U.TweenService,U.Lighting,U.SoundService,U.TeleportService,U.MarketplaceService,U.GuiService,U.VirtualUser,U.CoreGui,U.HttpService,U.Stats,U.ContentProvider,U.StarterGui
local LP,Camera,unpackArgs = U.LP,U.Camera,U.unpackArgs
local character,humanoid,root = U.character,U.humanoid,U.root
local GuiParent,C,ESP_PALETTE = U.GuiParent,U.C,U.ESP_PALETTE
local corner,stroke,gradient,padding = U.corner,U.stroke,U.gradient,U.padding
local S,original = U.S,U.original
local Gui,Main,Scale,refreshScale,Stars = U.Gui,U.Main,U.Scale,U.refreshScale,U.Stars
local MainLineFX,restartMainLineTweens = U.MainLineFX,U.restartMainLineTweens
local Header,NovaIcon,Title,SubTitle,Minimize,Mini,MiniLineFX,restartMiniLineTweens = U.Header,U.NovaIcon,U.Title,U.SubTitle,U.Minimize,U.Mini,U.MiniLineFX,U.restartMiniLineTweens
local toast = U.toast
local MenuAmbience,MenuWhoosh,syncMenuAudio = U.MenuAmbience,U.MenuWhoosh,U.syncMenuAudio
local Sidebar,SideList,Content,Pages,Navs = U.Sidebar,U.SideList,U.Content,U.Pages,U.Navs
local makePage,switchPage = U.makePage,U.switchPage
local Home,Cheats,PlayersPage,CameraPage,VisualsPage,Emotes,Shaders,ServerPage,PerformancePage,ToolsPage,SettingsPage = U.Home,U.Cheats,U.PlayersPage,U.CameraPage,U.VisualsPage,U.Emotes,U.Shaders,U.ServerPage,U.PerformancePage,U.ToolsPage,U.SettingsPage
local ControlRegistry,registerControl = U.ControlRegistry,U.registerControl
local heading,section,card,infoCard,button,toggle,slider = U.heading,U.section,U.card,U.infoCard,U.button,U.toggle,U.slider
local ModalDim,playerPicker = U.ModalDim,U.playerPicker

--========================================================
-- SHADERS
--========================================================
heading(Shaders,"SHADERS","14 presets • Mobile / High / Ultra")

local ShaderObjects = {}
local ShaderQuality = "Mobile"
local QualityOrder = {"Mobile","High","Ultra"}
local QualityIndex = 1
local CurrentShaderPreset = nil

local function qualityRank()
    if ShaderQuality == "Ultra" then return 3 end
    if ShaderQuality == "High" then return 2 end
    return 1
end

local function qualityValue(mobile,high,ultra)
    local rank = qualityRank()
    if rank == 3 then return ultra end
    if rank == 2 then return high end
    return mobile
end

local function trackShaderObject(obj)
    table.insert(ShaderObjects,obj)
    return obj
end

local ShaderWorldFolder = Instance.new("Folder")
ShaderWorldFolder.Name = "UltraNovaWorldFX"
ShaderWorldFolder.Parent = workspace

local MaterialBackup = {}
local TransparencyBackup = {}

local function clearShaderObjects()
    for _,obj in ipairs(ShaderObjects) do
        if obj and obj.Parent then pcall(function() obj:Destroy() end) end
    end
    ShaderObjects = {}
end

local function clearWorldShader()
    if ShaderWorldFolder and ShaderWorldFolder.Parent then ShaderWorldFolder:ClearAllChildren() end
    for part,data in pairs(MaterialBackup) do
        if part and part.Parent then
            pcall(function()
                part.Material = data.Material
                part.Color = data.Color
                part.Reflectance = data.Reflectance
            end)
        end
    end
    MaterialBackup = {}
    for part,val in pairs(TransparencyBackup) do
        if part and part.Parent then pcall(function() part.LocalTransparencyModifier = val end) end
    end
    TransparencyBackup = {}
end

local function resetShader()
    clearShaderObjects()
    clearWorldShader()
    Lighting.Brightness = original.Brightness
    Lighting.ClockTime = original.ClockTime
    Lighting.FogEnd = original.FogEnd
    Lighting.GlobalShadows = original.GlobalShadows
    Lighting.Ambient = original.Ambient
    Lighting.OutdoorAmbient = original.OutdoorAmbient
    Lighting.ExposureCompensation = original.ExposureCompensation
    Lighting.ColorShift_Top = original.ColorShiftTop
    Lighting.ColorShift_Bottom = original.ColorShiftBottom
    Lighting.EnvironmentDiffuseScale = original.EnvironmentDiffuseScale
    Lighting.EnvironmentSpecularScale = original.EnvironmentSpecularScale
end

local function addColor(tint,brightness,contrast,saturation)
    local e = Instance.new("ColorCorrectionEffect")
    e.Name = "UltraNovaColor"
    e.TintColor = tint or Color3.new(1,1,1)
    e.Brightness = brightness or 0
    e.Contrast = contrast or 0
    e.Saturation = saturation or 0
    e.Parent = Lighting
    return trackShaderObject(e)
end

local function addBloom(intensity,size,threshold)
    local e = Instance.new("BloomEffect")
    e.Name = "UltraNovaBloom"
    e.Intensity = intensity or .2
    e.Size = size or 28
    e.Threshold = threshold or 1.2
    e.Parent = Lighting
    return trackShaderObject(e)
end

local function addSun(intensity,spread)
    local e = Instance.new("SunRaysEffect")
    e.Name = "UltraNovaSun"
    e.Intensity = intensity or .05
    e.Spread = spread or .8
    e.Parent = Lighting
    return trackShaderObject(e)
end

local function addDOF(farIntensity,focusDistance,inFocusRadius,nearIntensity)
    if qualityRank() < 2 then return nil end
    local e = Instance.new("DepthOfFieldEffect")
    e.Name = "UltraNovaDOF"
    e.FarIntensity = farIntensity or .04
    e.FocusDistance = focusDistance or 40
    e.InFocusRadius = inFocusRadius or 55
    e.NearIntensity = nearIntensity or 0
    e.Parent = Lighting
    return trackShaderObject(e)
end

local function addBlur(size)
    if qualityRank() < 3 then return nil end
    local e = Instance.new("BlurEffect")
    e.Name = "UltraNovaBlur"
    e.Size = size or 1
    e.Parent = Lighting
    return trackShaderObject(e)
end

local function addAtmosphere(color,decay,density,haze,glare)
    local e = Instance.new("Atmosphere")
    e.Name = "UltraNovaAtmosphere"
    e.Color = color or Color3.fromRGB(190,200,255)
    e.Decay = decay or Color3.fromRGB(95,75,150)
    e.Density = density or .2
    e.Haze = haze or .5
    e.Glare = glare or 0
    e.Parent = Lighting
    return trackShaderObject(e)
end

local function backupMaterial(part)
    if not MaterialBackup[part] then
        MaterialBackup[part] = {Material=part.Material,Color=part.Color,Reflectance=part.Reflectance}
    end
end

local function polishWorld(mode)
    local limit = qualityValue(0,260,650)
    if limit <= 0 then return end
    local count = 0
    for _,part in ipairs(workspace:GetDescendants()) do
        if count >= limit then break end
        if part:IsA("BasePart")
        and not part:IsDescendantOf(character())
        and not Players:GetPlayerFromCharacter(part.Parent) then
            backupMaterial(part)
            if mode == "Realistic" then
                if part.Material == Enum.Material.Plastic then part.Material = Enum.Material.SmoothPlastic end
                part.Reflectance = math.clamp(part.Reflectance+.025,0,.18)
            elseif mode == "Neon" then
                if part.Material == Enum.Material.Plastic then part.Material = Enum.Material.SmoothPlastic end
                part.Reflectance = math.clamp(part.Reflectance+.08,0,.25)
            elseif mode == "Cartoon" then
                part.Material = Enum.Material.SmoothPlastic
                part.Reflectance = 0
            end
            count += 1
            if count%120 == 0 then task.wait() end
        end
    end
end

local function outlineWorld(color)
    local limit = qualityValue(110,320,650)
    local count = 0
    for _,part in ipairs(workspace:GetDescendants()) do
        if count >= limit then break end
        if part:IsA("BasePart")
        and not part:IsDescendantOf(character())
        and not Players:GetPlayerFromCharacter(part.Parent) then
            local box = Instance.new("SelectionBox")
            box.Name = "UltraNovaOutline"
            box.Adornee = part
            box.Color3 = color or C.White
            box.LineThickness = qualityValue(.014,.018,.022)
            box.SurfaceTransparency = 1
            box.Parent = ShaderWorldFolder
            count += 1
            if count%120 == 0 then task.wait() end
        end
    end
end

local ShaderPresets = {
    {
        Name="Ultra Realistic",
        Apply=function()
            Lighting.Brightness = qualityValue(2.0,2.15,2.25)
            Lighting.GlobalShadows = true
            Lighting.ExposureCompensation = qualityValue(.02,.07,.11)
            Lighting.EnvironmentDiffuseScale = qualityValue(.65,.78,.86)
            Lighting.EnvironmentSpecularScale = qualityValue(.70,.90,1)
            addColor(Color3.fromRGB(255,248,241),.01,qualityValue(.08,.12,.15),qualityValue(.03,.06,.08))
            addBloom(qualityValue(.13,.19,.24),qualityValue(22,28,34),1.35)
            addSun(qualityValue(.035,.055,.075),.82)
            addAtmosphere(Color3.fromRGB(205,216,232),Color3.fromRGB(110,120,145),qualityValue(.08,.12,.15),qualityValue(.25,.48,.70),.02)
            addDOF(qualityValue(0,.025,.045),48,qualityValue(80,65,55),0)
            polishWorld("Realistic")
        end
    },
    {
        Name="RoShade Style",
        Apply=function()
            Lighting.Brightness = 2.05
            Lighting.GlobalShadows = true
            Lighting.ExposureCompensation = .06
            Lighting.EnvironmentSpecularScale = qualityValue(.72,.92,1)
            addColor(Color3.fromRGB(255,241,233),.015,qualityValue(.13,.18,.23),qualityValue(.08,.13,.17))
            addBloom(qualityValue(.18,.28,.38),qualityValue(24,32,38),qualityValue(1.3,1.15,1))
            addSun(qualityValue(.045,.075,.105),.86)
            addAtmosphere(Color3.fromRGB(220,211,202),Color3.fromRGB(112,101,117),qualityValue(.09,.14,.18),qualityValue(.25,.55,.85),qualityValue(0,.03,.07))
            addDOF(.05,42,qualityValue(70,60,48),.005)
            polishWorld("Realistic")
        end
    },
    {
        Name="Cinematic",
        Apply=function()
            Lighting.Brightness = 1.85
            Lighting.ExposureCompensation = -.02
            Lighting.GlobalShadows = true
            addColor(Color3.fromRGB(239,231,226),-.015,qualityValue(.12,.19,.25),-.06)
            addBloom(qualityValue(.09,.14,.19),30,1.45)
            addDOF(qualityValue(0,.08,.15),32,qualityValue(90,42,30),qualityValue(0,.015,.035))
            addAtmosphere(Color3.fromRGB(205,201,195),Color3.fromRGB(90,85,92),.09,qualityValue(.15,.38,.52),0)
        end
    },
    {
        Name="Golden Rays",
        Apply=function()
            Lighting.ClockTime = 17.25
            Lighting.Brightness = 2.1
            addColor(Color3.fromRGB(255,210,164),.025,.11,.13)
            addSun(qualityValue(.08,.12,.16),.9)
            addBloom(qualityValue(.20,.30,.40),30,1.05)
            addAtmosphere(Color3.fromRGB(255,193,139),Color3.fromRGB(123,74,81),qualityValue(.12,.18,.23),qualityValue(.55,1,1.35),qualityValue(.05,.13,.20))
            addDOF(.04,45,70,0)
        end
    },
    {
        Name="RTX-ish Night",
        Apply=function()
            Lighting.ClockTime = 21.1
            Lighting.Brightness = qualityValue(1.15,1.30,1.45)
            Lighting.GlobalShadows = true
            Lighting.Ambient = Color3.fromRGB(24,29,48)
            Lighting.OutdoorAmbient = Color3.fromRGB(17,23,43)
            Lighting.EnvironmentSpecularScale = qualityValue(.75,.95,1)
            addColor(Color3.fromRGB(193,211,255),-.025,.21,.13)
            addBloom(qualityValue(.25,.40,.58),qualityValue(28,36,44),.88)
            addAtmosphere(Color3.fromRGB(88,108,160),Color3.fromRGB(18,24,53),qualityValue(.15,.23,.30),qualityValue(.45,1,1.55),.04)
            addDOF(.045,38,58,0)
            polishWorld("Realistic")
        end
    },
    {
        Name="Deep Space",
        Apply=function()
            Lighting.ClockTime = .05
            Lighting.Brightness = .92
            Lighting.Ambient = Color3.fromRGB(28,16,61)
            Lighting.OutdoorAmbient = Color3.fromRGB(13,19,46)
            addColor(Color3.fromRGB(194,172,255),-.025,.25,.24)
            addBloom(qualityValue(.35,.55,.75),40,.82)
            addAtmosphere(Color3.fromRGB(82,61,147),Color3.fromRGB(14,8,40),qualityValue(.22,.31,.39),qualityValue(1,1.8,2.5),qualityValue(.03,.10,.18))
            addDOF(.05,40,55,0)
        end
    },
    {
        Name="Cyber Purple",
        Apply=function()
            Lighting.ClockTime = 20.2
            Lighting.Brightness = 1.6
            Lighting.Ambient = Color3.fromRGB(56,25,95)
            Lighting.OutdoorAmbient = Color3.fromRGB(24,29,69)
            addColor(Color3.fromRGB(225,182,255),.015,.23,.27)
            addBloom(qualityValue(.42,.66,.85),40,.76)
            addAtmosphere(Color3.fromRGB(112,83,190),Color3.fromRGB(31,13,81),qualityValue(.20,.29,.36),qualityValue(.9,1.7,2.25),.12)
            addDOF(.04,42,60,0)
        end
    },
    {
        Name="Neon City",
        Apply=function()
            Lighting.ClockTime = 22
            Lighting.Brightness = 1.45
            Lighting.Ambient = Color3.fromRGB(38,20,69)
            addColor(Color3.fromRGB(215,184,255),.015,.23,.34)
            addBloom(qualityValue(.50,.76,.95),44,.68)
            addAtmosphere(Color3.fromRGB(79,75,145),Color3.fromRGB(19,13,55),.25,1.3,.1)
            polishWorld("Neon")
            if qualityRank() >= 2 then outlineWorld(C.Purple) end
        end
    },
    {
        Name="Dreamy",
        Apply=function()
            Lighting.ClockTime = 8.25
            Lighting.Brightness = 2.25
            addColor(Color3.fromRGB(255,218,246),.045,-.04,.08)
            addBloom(qualityValue(.32,.52,.72),44,.78)
            addAtmosphere(Color3.fromRGB(234,205,255),Color3.fromRGB(134,113,169),.14,.55,.03)
            addDOF(qualityValue(0,.08,.16),28,qualityValue(90,40,28),.02)
            addBlur(1)
        end
    },
    {
        Name="Clean HD",
        Apply=function()
            Lighting.Brightness = 2.15
            Lighting.GlobalShadows = true
            Lighting.EnvironmentDiffuseScale = .8
            Lighting.EnvironmentSpecularScale = qualityValue(.75,.90,1)
            addColor(Color3.fromRGB(255,252,248),.01,qualityValue(.09,.14,.18),qualityValue(.04,.07,.10))
            addBloom(.08,20,1.65)
            polishWorld("Realistic")
        end
    },
    {
        Name="Ice World",
        Apply=function()
            Lighting.ClockTime = 11.5
            Lighting.Brightness = 2.1
            addColor(Color3.fromRGB(184,238,255),.025,.15,.04)
            addBloom(qualityValue(.18,.30,.42),34,1.05)
            addAtmosphere(Color3.fromRGB(184,232,255),Color3.fromRGB(86,125,166),.17,qualityValue(.35,.65,.95),.05)
            addDOF(.03,48,70,0)
        end
    },
    {
        Name="Crimson",
        Apply=function()
            Lighting.ClockTime = 19.4
            Lighting.Brightness = 1.4
            Lighting.Ambient = Color3.fromRGB(91,17,27)
            Lighting.OutdoorAmbient = Color3.fromRGB(58,15,23)
            addColor(Color3.fromRGB(255,139,145),-.015,.23,.18)
            addBloom(qualityValue(.22,.36,.48),30,1.04)
            addAtmosphere(Color3.fromRGB(166,64,69),Color3.fromRGB(59,12,24),.24,qualityValue(.55,1,1.45),.07)
        end
    },
    {
        Name="Cel Outline",
        Apply=function()
            Lighting.Brightness = 2
            addColor(Color3.fromRGB(255,249,255),.02,.25,.18)
            polishWorld("Cartoon")
            outlineWorld(Color3.fromRGB(245,245,255))
        end
    },
    {
        Name="Retro Film",
        Apply=function()
            Lighting.Brightness = 1.8
            Lighting.ColorShift_Top = Color3.fromRGB(24,7,16)
            Lighting.ColorShift_Bottom = Color3.fromRGB(5,10,24)
            addColor(Color3.fromRGB(255,218,186),.01,.10,-.17)
            addBloom(.13,20,1.4)
            addDOF(.025,40,70,0)
            addAtmosphere(Color3.fromRGB(206,183,164),Color3.fromRGB(102,84,79),.08,.22,0)
        end
    }
}

local function applyShaderPreset(preset)
    if not preset then return end
    CurrentShaderPreset = preset
    S.activeShader = preset.Name
    resetShader()
    toast("Loading "..preset.Name.."...",C.Cyan)
    task.spawn(function()
        local ok = pcall(preset.Apply)
        if ok then
            toast(preset.Name.." • "..ShaderQuality,C.Purple)
        else
            toast("Shader error",C.Red)
        end
    end)
end

local ShaderQualityButton
ShaderQualityButton = select(1,button(Shaders,"Qualità Shader: MOBILE",function(b)
    QualityIndex = QualityIndex%3+1
    ShaderQuality = QualityOrder[QualityIndex]
    b.Text = "Qualità Shader: "..string.upper(ShaderQuality)
    toast("Shader Quality: "..ShaderQuality,C.Cyan)
    if CurrentShaderPreset then applyShaderPreset(CurrentShaderPreset) end
end))

infoCard(
    Shaders,
    "◈ Quality Mode",
    "Mobile usa effetti leggeri. High aggiunge profondità, materiali e più dettagli. Ultra usa il preset completo e modifica più elementi della scena."
)

button(Shaders,"↺  Reset Shader / Ripristina",function()
    CurrentShaderPreset = nil
    S.activeShader = "None"
    resetShader()
    toast("Shader reset ✦",C.Cyan)
end)

section(Shaders,"PRESETS")

for index,preset in ipairs(ShaderPresets) do
    button(Shaders,string.format("%02d  ✦  %s",index,preset.Name),function()
        applyShaderPreset(preset)
    end)
end

infoCard(
    Shaders,
    "◈ UltraNova Visual Engine",
    "Ultra Realistic, RoShade Style, Cinematic, Golden Rays, RTX-ish Night, Deep Space, Cyber Purple, Neon City, Dreamy, Clean HD, Ice World, Crimson, Cel Outline e Retro Film."
)





U.resetShader = resetShader
U.ShaderWorldFolder = ShaderWorldFolder
U.ShaderPresets = ShaderPresets
U.applyShaderPreset = applyShaderPreset
